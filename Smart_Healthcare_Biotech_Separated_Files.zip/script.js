
        const allSymptoms = [
            { id: 'fever', category: 'respiratory', name: 'Fever & Thermal Chills', telugu: 'జ్వరం మరియు చలి', emoji: '🤒', desc: 'Pyrexia, shivering, thermal flush, diaphoresis' },
            { id: 'cough', category: 'respiratory', name: 'Cough & Rhinorrhea', telugu: 'దగ్గు మరియు జలుబు', emoji: '😷', desc: 'Bronchial irritation, sneezing, pharyngeal congestion' },
            { id: 'throat', category: 'respiratory', name: 'Sore Pharynx / Throat', telugu: 'గొంతు నొప్పి మరియు ఇన్ఫెక్షన్', emoji: '🗣️', desc: 'Odynophagia, tonsillar erythema, scratchy dysphagia' },
            { id: 'wheeze', category: 'respiratory', name: 'Wheezing & Dyspnea', telugu: 'శ్వాసలో పిల్లికూతలు, ఆయాసం', emoji: '🫁', desc: 'Prolonged expiratory wheeze, shallow chest tightness' },
            { id: 'headache', category: 'cranial', name: 'Cranial Tension Headache', telugu: 'తీవ్రమైన తలనొప్పి', emoji: '🧠', desc: 'Bilateral band-like pressure, occipital tension' },
            { id: 'migraine', category: 'cranial', name: 'Vascular Migraine with Aura', telugu: 'మైగ్రేన్ పార్శ్వపు తలనొప్పి', emoji: '⚡', desc: 'Unilateral throbbing, photophobia, sensory visual scotoma' },
            { id: 'vertigo', category: 'cranial', name: 'Vestibular Vertigo & Dizziness', telugu: 'తలతిరుగుడు మరియు మైకం', emoji: '🌀', desc: 'Rotational spinning sensation, BPPV positional instability' },
            { id: 'stomach', category: 'gastro', name: 'Gastrointestinal Dyspepsia', telugu: 'కడుపు నొప్పి మరియు అజీర్ణం', emoji: '🤢', desc: 'Nausea, epigastric pyrosis, abdominal cramping' },
            { id: 'diarrhea', category: 'gastro', name: 'Enteric Fluid Loss / Diarrhea', telugu: 'విరేచనాలు మరియు నీరసం', emoji: '🚽', desc: 'Watery frequent stools, intestinal hypermotility' },
            { id: 'gerd', category: 'gastro', name: 'Acid Reflux & Heartburn', telugu: 'ఎసిడిటీ మరియు గుండెల్లో మంట', emoji: '🔥', desc: 'Retrosternal acid regurgitation, postprandial burn' },
            { id: 'palpitation', category: 'cardiac', name: 'Palpitations & Tachycardia', telugu: 'గుండె దడ మరియు వేగవంతమైన స్పందన', emoji: '❤️', desc: 'Racing cardiac beat, missed beats, sinus rate >100' },
            { id: 'lightheaded', category: 'cardiac', name: 'Orthostatic Lightheadedness', telugu: 'నిలబడినప్పుడు కళ్లు తిరగడం', emoji: '💫', desc: 'Postural blood pressure drop, presyncopal dizziness' },
            { id: 'backpain', category: 'musculo', name: 'Acute Lumbosacral Back Strain', telugu: 'నడుము నొప్పి మరియు కండరాల పట్టడం', emoji: '🦴', desc: 'Lower back muscle spasms, stiffness upon flexion' },
            { id: 'joint', category: 'musculo', name: 'Joint Arthralgia & Stiffness', telugu: 'కీళ్ల నొప్పులు మరియు వాపు', emoji: '🦵', desc: 'Articular tenderness, movement restriction, knee/finger pain' },
            { id: 'rash', category: 'derm', name: 'Pruritic Rash & Urticaria', telugu: 'దురద, దద్దుర్లు మరియు అలెర్జీ', emoji: '🩹', desc: 'Itchy erythematous wheals, contact dermatitis' },
            { id: 'shingles', category: 'derm', name: 'Localized Burning & Eruption', telugu: 'చర్మంలో మంట మరియు పొక్కులు', emoji: '🔥', desc: 'Unilateral dermatomal nerve pain, erythematous clusters' }
        ];

        const appState = {
            activePage: 1,
            wizardStep: 1,
            wizardTotal: 3,
            selectedCategory: 'all',
            symptom: 'Fever & Thermal Chills',
            symptomId: 'fever',
            symptomTelugu: 'జ్వరం మరియు చలి',
            symptomEmoji: '🤒',
            symptomCategory: 'Respiratory & Febrile',
            days: 3,
            severity: 'Moderate (Grade 2)',
            severityTelugu: 'మధ్యస్థం (గ్రేడ్ 2)',
            severityEmoji: '😐',
            activeMetric: 'temp',
            currentLanguage: 'en',
            ttsEnabled: true,
            isListening: false,
            bgMode: 'mesh'
        };

        function renderSymptomCards(filter = 'all') {
            const container = document.getElementById('symptoms-container');
            const filtered = filter === 'all' ? allSymptoms : allSymptoms.filter(s => s.category === filter);

            container.innerHTML = filtered.map(s => `
                <div class="hud-card ${appState.symptom === s.name ? 'selected' : ''}" onclick="chooseSymptom('${s.name}', '${s.emoji}', '${s.category}', '${s.telugu}', this, '${s.id}')">
                    <div class="card-glare"></div>
                    <div class="icon-orb">${s.emoji}</div>
                    <span>${s.name}</span>
                    <small>${s.desc}</small>
                    <span class="card-telugu-hint">${s.telugu}</span>
                </div>
            `).join('');

            bindCard3DPhysics();
        }
        renderSymptomCards();

        function filterCategory(cat, chip) {
            appState.selectedCategory = cat;
            document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active-cat'));
            chip.classList.add('active-cat');
            renderSymptomCards(cat);
        }

        const mainShell = document.getElementById('main-shell');
        const cursorAura = document.getElementById('bio-cursor-aura');
        let mouseX = window.innerWidth / 2;
        let mouseY = window.innerHeight / 2;
        let auraX = mouseX;
        let auraY = mouseY;

        document.addEventListener('mousemove', (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;

            const rect = mainShell.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;

            const deltaX = (e.clientX - centerX) / (window.innerWidth / 2);
            const deltaY = (e.clientY - centerY) / (window.innerHeight / 2);

            mainShell.style.setProperty('--mouse-x', `${e.clientX - rect.left}px`);
            mainShell.style.setProperty('--mouse-y', `${e.clientY - rect.top}px`);
            mainShell.style.setProperty('transform', 'none', 'important');

            document.querySelectorAll('.hud-card').forEach(card => {
                const cRect = card.getBoundingClientRect();
                card.style.setProperty('--card-mx', `${e.clientX - cRect.left}px`);
                card.style.setProperty('--card-my', `${e.clientY - cRect.top}px`);
            });
        });

        function animateCursorAura() {
            auraX += (mouseX - auraX) * 0.12;
            auraY += (mouseY - auraY) * 0.12;
            if (cursorAura) {
                cursorAura.style.left = `${auraX}px`;
                cursorAura.style.top = `${auraY}px`;
            }
            requestAnimationFrame(animateCursorAura);
        }
        animateCursorAura();

        function bindCard3DPhysics() {
            document.querySelectorAll('.hud-card').forEach(card => {
                card.addEventListener('mousemove', (e) => {
                    const rect = card.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const y = e.clientY - rect.top;
                    const cx = rect.width / 2;
                    const cy = rect.height / 2;
                    const rx = ((y - cy) / cy) * -8;
                    const ry = ((x - cx) / cx) * 8;
                    card.style.setProperty('transform', 'none', 'important');
                });
                card.addEventListener('mouseleave', () => {
                    card.style.setProperty('transform', 'none', 'important');
                });
            });
        }

        const vitalsHistory = [
            { day: 'Day -6', date: 'Oct 10', temp: 98.4, hr: 68, spo2: 99, score: 0.5, condition: 'Normal Baseline', status: 'normal' },
            { day: 'Day -5', date: 'Oct 11', temp: 98.8, hr: 70, spo2: 99, score: 1.5, condition: 'Mild scratchy pharynx', status: 'normal' },
            { day: 'Day -4', date: 'Oct 12', temp: 100.2, hr: 80, spo2: 98, score: 4.8, condition: 'Fever onset, myalgia', status: 'subfebrile' },
            { day: 'Day -3', date: 'Oct 13', temp: 101.2, hr: 86, spo2: 97, score: 7.0, condition: 'Peak chills, fever spikes', status: 'fever' },
            { day: 'Day -2', date: 'Oct 14', temp: 100.4, hr: 82, spo2: 98, score: 5.2, condition: 'Subfebrile, diaphoresis', status: 'subfebrile' },
            { day: 'Day -1', date: 'Oct 15', temp: 99.2, hr: 75, spo2: 98, score: 3.5, condition: 'Residual fatigue, defervescence', status: 'subfebrile' },
            { day: 'Today',  date: 'Current', temp: 98.9, hr: 74, spo2: 98, score: 3.0, condition: 'Current screener status', status: 'normal' }
        ];

        document.getElementById('report-date').textContent = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

        function switchPage(pageNumber) {
            appState.activePage = pageNumber;
            document.querySelectorAll('.nav-tab').forEach((tab, index) => tab.classList.toggle('active', (index + 1) === pageNumber));
            document.querySelectorAll('.hud-page').forEach((page, index) => page.classList.toggle('active-page', (index + 1) === pageNumber));

            window.scrollTo({ top: 0, behavior: 'auto' });

            if (pageNumber === 2) renderHistoryChart();
            if (pageNumber === 7) updateReportDetails();

            if (pageNumber === 5) {
                speakText(appState.currentLanguage === 'te' 
                    ? "అత్యవసర విభాగం. అవసరమైతే 108 లేదా 112 కు కాల్ చేయండి." 
                    : "Emergency Guidance active. Dial 108 or 112 for urgent medical assistance.");
            }
        }

        // ========================================================
        // REALISTIC BIOMOLECULAR & SYNAPSE CANVAS SYSTEM
        // ========================================================
        const bioCanvas = document.getElementById('bio-canvas');
        const bCtx = bioCanvas.getContext('2d');
        let bioNodes = [];
        let bioVesicles = [];
        let bioPulses = [];

        function resizeBioCanvas() {
            const dpr = Math.min(window.devicePixelRatio || 1, 1.25);
            bioCanvas.width = Math.round(window.innerWidth * dpr);
            bioCanvas.height = Math.round(window.innerHeight * dpr);
            bioCanvas.style.width = window.innerWidth + 'px';
            bioCanvas.style.height = window.innerHeight + 'px';
            bCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
            initBioEnvironment();
        }
        window.addEventListener('resize', () => {
            resizeBioCanvas();
            if (appState.activePage === 2) renderHistoryChart();
        });

        const BIO_PALETTES = {
            cyan: { base: '#06b6d4', glow: 'rgba(6, 182, 212, 0.6)' },
            emerald: { base: '#10b981', glow: 'rgba(16, 185, 129, 0.6)' },
            blue: { base: '#38bdf8', glow: 'rgba(56, 189, 248, 0.6)' },
            purple: { base: '#8b5cf6', glow: 'rgba(139, 92, 246, 0.5)' }
        };

        class BioNode {
            constructor() {
                this.x = Math.random() * window.innerWidth;
                this.y = Math.random() * window.innerHeight;
                this.vx = (Math.random() - 0.5) * 0.7;
                this.vy = (Math.random() - 0.5) * 0.7;
                this.radius = Math.random() * 2.5 + 1.8;
                const colors = ['cyan', 'emerald', 'blue', 'purple'];
                this.colorKey = colors[Math.floor(Math.random() * colors.length)];
                this.pulsePhase = Math.random() * Math.PI * 2;
            }

            update() {
                this.x += this.vx;
                this.y += this.vy;

                if (this.x < 0 || this.x > window.innerWidth) this.vx *= -1;
                if (this.y < 0 || this.y > window.innerHeight) this.vy *= -1;

                const dx = mouseX - this.x;
                const dy = mouseY - this.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < 140 && dist > 1) {
                    const force = (140 - dist) / 140;
                    this.x -= (dx / dist) * force * 1.5;
                    this.y -= (dy / dist) * force * 1.5;
                }

                this.pulsePhase += 0.04;
            }

            draw() {
                const color = BIO_PALETTES[this.colorKey];
                const dynamicRadius = this.radius + Math.sin(this.pulsePhase) * 0.6;

                bCtx.save();
                bCtx.fillStyle = color.base;
                bCtx.shadowColor = color.glow;
                bCtx.shadowBlur = 10;
                bCtx.beginPath();
                bCtx.arc(this.x, this.y, Math.max(1, dynamicRadius), 0, Math.PI * 2);
                bCtx.fill();
                bCtx.restore();
            }
        }

        class CellularVesicle {
            constructor() {
                this.x = Math.random() * window.innerWidth;
                this.y = Math.random() * window.innerHeight;
                this.radius = Math.random() * 55 + 30;
                this.vx = (Math.random() - 0.5) * 0.2;
                this.vy = (Math.random() - 0.5) * 0.2;
                this.hue = Math.random() > 0.5 ? 185 : 155;
                this.phase = Math.random() * Math.PI * 2;
            }

            update() {
                this.x += this.vx;
                this.y += this.vy;
                if (this.x < -100) this.x = window.innerWidth + 100;
                if (this.x > window.innerWidth + 100) this.x = -100;
                if (this.y < -100) this.y = window.innerHeight + 100;
                if (this.y > window.innerHeight + 100) this.y = -100;
                this.phase += 0.015;
            }

            draw() {
                bCtx.save();
                const r = this.radius + Math.sin(this.phase) * 6;
                const g = bCtx.createRadialGradient(this.x, this.y, r * 0.1, this.x, this.y, r);
                g.addColorStop(0, `hsla(${this.hue}, 80%, 65%, 0.06)`);
                g.addColorStop(0.6, `hsla(${this.hue}, 80%, 55%, 0.03)`);
                g.addColorStop(1, 'transparent');
                bCtx.fillStyle = g;
                bCtx.beginPath();
                bCtx.arc(this.x, this.y, r, 0, Math.PI * 2);
                bCtx.fill();

                bCtx.fillStyle = `hsla(${this.hue + 20}, 90%, 70%, 0.04)`;
                bCtx.beginPath();
                bCtx.arc(this.x + Math.sin(this.phase) * 6, this.y + Math.cos(this.phase) * 6, r * 0.35, 0, Math.PI * 2);
                bCtx.fill();
                bCtx.restore();
            }
        }

        class BioSignalPulse {
            constructor(nodeA, nodeB) {
                this.nodeA = nodeA;
                this.nodeB = nodeB;
                this.progress = 0;
                this.speed = Math.random() * 0.03 + 0.02;
            }

            update() {
                this.progress += this.speed;
                return this.progress <= 1;
            }

            draw() {
                const px = this.nodeA.x + (this.nodeB.x - this.nodeA.x) * this.progress;
                const py = this.nodeA.y + (this.nodeB.y - this.nodeA.y) * this.progress;

                bCtx.save();
                bCtx.fillStyle = '#ffffff';
                bCtx.shadowColor = '#06b6d4';
                bCtx.shadowBlur = 12;
                bCtx.beginPath();
                bCtx.arc(px, py, 2.2, 0, Math.PI * 2);
                bCtx.fill();
                bCtx.restore();
            }
        }

        function initBioEnvironment() {
            bioNodes = [];
            bioVesicles = [];
            bioPulses = [];
            const mobile = window.matchMedia('(max-width: 700px)').matches || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
            const area = window.innerWidth * window.innerHeight;
            const count = Math.min(mobile ? 28 : 58, Math.floor(area / (mobile ? 26000 : 19000)));
            for (let i = 0; i < count; i++) bioNodes.push(new BioNode());
            for (let i = 0; i < 14; i++) bioVesicles.push(new CellularVesicle());
        }
        resizeBioCanvas();

        function setBioBackgroundMode(mode) {
            appState.bgMode = mode;
            document.querySelectorAll('.mode-chip').forEach(c => c.classList.remove('active'));
            const target = document.getElementById(`mode-${mode}`);
            if (target) target.classList.add('active');
        }

        let lastBioFrame = 0;
        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        document.addEventListener('visibilitychange', () => { if (!document.hidden && !reducedMotion) requestAnimationFrame(animateBioAtmosphere); });
        function animateBioAtmosphere(timestamp) {
            if (document.hidden || reducedMotion) return;
            if (timestamp - lastBioFrame < 33) { requestAnimationFrame(animateBioAtmosphere); return; }
            lastBioFrame = timestamp;
            bCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);

            if (appState.bgMode === 'cells' || appState.bgMode === 'mesh') {
                bioVesicles.forEach(v => {
                    v.update();
                    v.draw();
                });
            }

            const maxDist = appState.bgMode === 'neural' ? 145 : 115;
            for (let i = 0; i < bioNodes.length; i++) {
                for (let j = i + 1; j < bioNodes.length; j++) {
                    const dx = bioNodes[i].x - bioNodes[j].x;
                    const dy = bioNodes[i].y - bioNodes[j].y;
                    const dist = Math.sqrt(dx * dx + dy * dy);

                    if (dist < maxDist) {
                        const alpha = (1 - dist / maxDist) * 0.32;
                        bCtx.strokeStyle = appState.bgMode === 'neural' 
                            ? `rgba(139, 92, 246, ${alpha * 1.2})` 
                            : `rgba(6, 182, 212, ${alpha})`;
                        bCtx.lineWidth = 1;
                        bCtx.beginPath();
                        bCtx.moveTo(bioNodes[i].x, bioNodes[i].y);
                        bCtx.lineTo(bioNodes[j].x, bioNodes[j].y);
                        bCtx.stroke();

                        if (Math.random() < 0.0007 && bioPulses.length < 24) {
                            bioPulses.push(new BioSignalPulse(bioNodes[i], bioNodes[j]));
                        }
                    }
                }
            }

            for (let i = bioPulses.length - 1; i >= 0; i--) {
                if (bioPulses[i].update()) {
                    bioPulses[i].draw();
                } else {
                    bioPulses.splice(i, 1);
                }
            }

            bioNodes.forEach(node => {
                node.update();
                node.draw();
            });

            requestAnimationFrame(animateBioAtmosphere);
        }
        if (!reducedMotion) requestAnimationFrame(animateBioAtmosphere);

        // 3D DNA Double Helix Scanner
        const dnaCanvas = document.getElementById('dna-canvas-3d');
        const dnaCtx = dnaCanvas.getContext('2d');
        dnaCanvas.width = 200;
        dnaCanvas.height = 200;

        let dnaAngle = 0;
        function render3DDNA() {
            dnaCtx.clearRect(0, 0, dnaCanvas.width, dnaCanvas.height);
            const cx = dnaCanvas.width / 2;
            const cy = dnaCanvas.height / 2;
            const radius = 50;
            const nodes = 22;
            const height = 150;

            const baseColorPairs = [
                { b1: '#06b6d4', b2: '#38bdf8', name1: 'A', name2: 'T' },
                { b1: '#10b981', b2: '#f43f5e', name1: 'G', name2: 'C' }
            ];

            const strandA = [];
            const strandB = [];
            for (let i = 0; i < nodes; i++) {
                const t = i / nodes;
                const y = (t - 0.5) * height + cy;
                const theta = t * Math.PI * 3.5 + dnaAngle;

                const x1 = Math.cos(theta) * radius;
                const z1 = Math.sin(theta) * radius;

                const x2 = Math.cos(theta + Math.PI) * radius;
                const z2 = Math.sin(theta + Math.PI) * radius;

                strandA.push({ x: cx + x1, y, z: z1, idx: i });
                strandB.push({ x: cx + x2, y, z: z2, idx: i });
            }

            for (let i = 0; i < nodes; i++) {
                const p1 = strandA[i];
                const p2 = strandB[i];
                const pair = baseColorPairs[i % 2];

                const avgZ = (p1.z + p2.z) / 2;
                const rungAlpha = Math.max(0.15, (avgZ + radius) / (radius * 2) * 0.6);
                dnaCtx.strokeStyle = `rgba(56, 189, 248, ${rungAlpha})`;
                dnaCtx.lineWidth = 1.8;
                dnaCtx.beginPath();
                dnaCtx.moveTo(p1.x, p1.y);
                dnaCtx.lineTo(p2.x, p2.y);
                dnaCtx.stroke();

                const scale1 = (p1.z + 80) / 80;
                dnaCtx.save();
                dnaCtx.beginPath();
                dnaCtx.arc(p1.x, p1.y, Math.max(1.2, 3.8 * scale1), 0, Math.PI * 2);
                dnaCtx.fillStyle = pair.b1;
                dnaCtx.shadowColor = pair.b1;
                dnaCtx.shadowBlur = p1.z > 0 ? 10 : 2;
                dnaCtx.fill();
                dnaCtx.restore();

                const scale2 = (p2.z + 80) / 80;
                dnaCtx.save();
                dnaCtx.beginPath();
                dnaCtx.arc(p2.x, p2.y, Math.max(1.2, 3.8 * scale2), 0, Math.PI * 2);
                dnaCtx.fillStyle = pair.b2;
                dnaCtx.shadowColor = pair.b2;
                dnaCtx.shadowBlur = p2.z > 0 ? 10 : 2;
                dnaCtx.fill();
                dnaCtx.restore();
            }

            dnaAngle += 0.038;
            requestAnimationFrame(render3DDNA);
        }
        render3DDNA();

        // ICU ECG Monitor
        const ecgCanvas = document.getElementById('ecg-canvas-mini');
        const ecgCtx = ecgCanvas.getContext('2d');
        ecgCanvas.width = 140;
        ecgCanvas.height = 44;
        let ecgSweepX = 0;
        const ecgPoints = new Array(ecgCanvas.width).fill(22);
        const ecgLed = document.getElementById('ecg-led');

        function drawRealisticECG() {
            ecgCtx.fillStyle = 'rgba(2, 6, 23, 0.12)';
            ecgCtx.fillRect(0, 0, ecgCanvas.width, ecgCanvas.height);

            const speed = 2;
            for (let step = 0; step < speed; step++) {
                ecgSweepX = (ecgSweepX + 1) % ecgCanvas.width;
                const cycle = ecgSweepX % 85;
                let y = 22;

                if (cycle >= 20 && cycle < 28) {
                    y = 22 - Math.sin((cycle - 20) / 8 * Math.PI) * 4;
                } else if (cycle >= 32 && cycle < 35) {
                    y = 22 + 4;
                } else if (cycle >= 35 && cycle < 40) {
                    y = 22 - 18;
                    if (cycle === 37 && ecgLed) {
                        ecgLed.classList.add('beat');
                        setTimeout(() => ecgLed.classList.remove('beat'), 120);
                    }
                } else if (cycle >= 40 && cycle < 44) {
                    y = 22 + 6;
                } else if (cycle >= 52 && cycle < 66) {
                    y = 22 - Math.sin((cycle - 52) / 14 * Math.PI) * 6;
                }

                ecgPoints[ecgSweepX] = y;
                const eraseAhead = (ecgSweepX + 6) % ecgCanvas.width;
                ecgPoints[eraseAhead] = 22;
            }

            ecgCtx.strokeStyle = '#10b981';
            ecgCtx.lineWidth = 2.2;
            ecgCtx.shadowColor = '#34d399';
            ecgCtx.shadowBlur = 8;
            ecgCtx.beginPath();

            for (let x = 0; x < ecgCanvas.width; x++) {
                if (Math.abs(x - ecgSweepX) < 4) continue;
                const y = ecgPoints[x];
                if (x === 0) ecgCtx.moveTo(x, y);
                else ecgCtx.lineTo(x, y);
            }
            ecgCtx.stroke();

            ecgCtx.fillStyle = '#ffffff';
            ecgCtx.shadowColor = '#38bdf8';
            ecgCtx.shadowBlur = 12;
            ecgCtx.beginPath();
            ecgCtx.arc(ecgSweepX, ecgPoints[ecgSweepX], 2.4, 0, Math.PI * 2);
            ecgCtx.fill();

            requestAnimationFrame(drawRealisticECG);
        }
        drawRealisticECG();

        // Audio Wave
        const waveCanvas = document.getElementById('voice-audio-wave');
        const waveCtx = waveCanvas.getContext('2d');
        waveCanvas.width = 190;
        waveCanvas.height = 52;
        let wavePhase = 0;

        function drawVoiceWave() {
            waveCtx.clearRect(0, 0, waveCanvas.width, waveCanvas.height);
            const active = appState.isListening;
            const mid = waveCanvas.height / 2;
            
            waveCtx.lineWidth = 2;
            waveCtx.strokeStyle = active ? '#ec4899' : '#06b6d4';
            waveCtx.shadowColor = active ? '#ec4899' : '#38bdf8';
            waveCtx.shadowBlur = active ? 12 : 5;
            waveCtx.beginPath();

            for (let x = 0; x < waveCanvas.width; x++) {
                const amp = active ? 16 : 3;
                const freq = active ? 0.08 : 0.04;
                const y = mid + Math.sin(x * freq + wavePhase) * Math.cos(x * 0.02 + wavePhase * 0.6) * amp;
                if (x === 0) waveCtx.moveTo(x, y);
                else waveCtx.lineTo(x, y);
            }
            waveCtx.stroke();
            wavePhase += active ? 0.22 : 0.05;
            requestAnimationFrame(drawVoiceWave);
        }
        drawVoiceWave();

        // Reliable bilingual voice engine (browser speech recognition)
        let speechRecognizer = null;
        let recognitionStarting = false;
        const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
        const micStatusLabel = () => document.getElementById('mic-status-label');
        const micStatusDot = () => document.getElementById('mic-status-dot');
        const voiceQuote = () => document.getElementById('voice-quote');

        function showMicMessage(message, isError = false) {
            if (voiceQuote()) voiceQuote().textContent = message;
            if (micStatusLabel()) micStatusLabel().textContent = isError
                ? (appState.currentLanguage === 'te' ? 'మైక్ సమస్య' : 'MICROPHONE ISSUE')
                : (appState.currentLanguage === 'te' ? 'మళ్లీ ప్రయత్నించండి' : 'READY TO TRY AGAIN');
        }

        if (SpeechRecognitionAPI) {
            speechRecognizer = new SpeechRecognitionAPI();
            speechRecognizer.continuous = false;
            speechRecognizer.interimResults = true;
            speechRecognizer.maxAlternatives = 1;

            speechRecognizer.onstart = () => {
                recognitionStarting = false;
                appState.isListening = true;
                document.getElementById('voice-mic').classList.add('active-pulse');
                document.getElementById('voice-dock-btn').classList.add('listening');
                micStatusDot().textContent = '🔴';
                micStatusLabel().textContent = appState.currentLanguage === 'te'
                    ? 'వింటున్నాను... మాట్లాడండి'
                    : 'LISTENING... SPEAK NOW';
            };

            speechRecognizer.onresult = (event) => {
                let interim = '';
                let finalText = '';
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const phrase = event.results[i][0].transcript;
                    if (event.results[i].isFinal) finalText += phrase;
                    else interim += phrase;
                }
                const shownText = (finalText || interim).trim();
                if (shownText && voiceQuote()) voiceQuote().textContent = `"${shownText}"`;
                if (finalText.trim()) processVoiceCommand(finalText.trim());
            };

            speechRecognizer.onerror = (event) => {
                recognitionStarting = false;
                stopVoiceListening();
                const messages = {
                    'not-allowed': appState.currentLanguage === 'te'
                        ? 'మైక్రోఫోన్ అనుమతి ఇవ్వండి. బ్రౌజర్ సెట్టింగ్స్‌లో Microphone Allow చేయండి.'
                        : 'Microphone permission was blocked. Allow microphone access in your browser settings.',
                    'service-not-allowed': appState.currentLanguage === 'te'
                        ? 'ఈ బ్రౌజర్‌లో వాయిస్ సేవ అందుబాటులో లేదు.'
                        : 'Speech service is unavailable in this browser.',
                    'no-speech': appState.currentLanguage === 'te'
                        ? 'మీ మాట వినిపించలేదు. మైక్ నొక్కి మళ్లీ మాట్లాడండి.'
                        : 'No speech detected. Tap the mic and speak clearly again.',
                    'audio-capture': appState.currentLanguage === 'te'
                        ? 'మైక్రోఫోన్ కనబడలేదు. మీ మైక్‌ను తనిఖీ చేయండి.'
                        : 'No microphone was detected. Check your device microphone.',
                    'network': appState.currentLanguage === 'te'
                        ? 'వాయిస్ గుర్తింపుకు నెట్‌వర్క్ అవసరం కావచ్చు. కనెక్షన్ తనిఖీ చేయండి.'
                        : 'Speech recognition needs a network connection in this browser. Check your connection.'
                };
                showMicMessage('"' + (messages[event.error] ||
                    (appState.currentLanguage === 'te'
                        ? 'వాయిస్ గుర్తింపు విఫలమైంది. దయచేసి మళ్లీ ప్రయత్నించండి.'
                        : 'Voice recognition failed. Please tap the mic and try again.')) + '"', true);
            };

            speechRecognizer.onend = () => {
                recognitionStarting = false;
                stopVoiceListening();
                // Preserve the recognized transcript or error message for the user.
            };
        }

        async function toggleSpeechRecognition() {
            if (appState.isListening || recognitionStarting) {
                try { if (speechRecognizer) speechRecognizer.stop(); } catch (e) {}
                recognitionStarting = false;
                stopVoiceListening();
                return;
            }

            if (!SpeechRecognitionAPI || !speechRecognizer) {
                showMicMessage(appState.currentLanguage === 'te'
                    ? 'ఈ బ్రౌజర్‌లో వాయిస్ గుర్తింపు లేదు. Androidలో Chromeలో HTTPS వెబ్‌సైట్ తెరవండి.'
                    : 'Speech recognition is not supported in this browser. Open this HTTPS website in updated Chrome.', true);
                return;
            }
            if (!window.isSecureContext && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
                showMicMessage(appState.currentLanguage === 'te'
                    ? 'మైక్ కోసం HTTPS వెబ్‌సైట్‌ను తెరవండి. ఫైల్‌ను నేరుగా తెరవకండి.'
                    : 'Microphone access requires HTTPS. Open the hosted website, not a local file.', true);
                return;
            }

            recognitionStarting = true;
            if (voiceQuote()) voiceQuote().textContent = appState.currentLanguage === 'te'
                ? 'మైక్ అనుమతి తనిఖీ చేస్తోంది… మాట్లాడటానికి సిద్ధంగా ఉండండి.'
                : 'Checking microphone… get ready to speak.';
            if (micStatusLabel()) micStatusLabel().textContent = appState.currentLanguage === 'te' ? 'మైక్ తనిఖీ…' : 'CHECKING MICROPHONE…';

            try {
                // Explicitly request permission first; release the stream before Web Speech starts.
                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    throw new Error('MIC_PERMISSION_API_UNAVAILABLE');
                }
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                stream.getTracks().forEach(track => track.stop());
                if (!recognitionStarting) return;
                speechRecognizer.lang = appState.currentLanguage === 'te' ? 'te-IN' : 'en-IN';
                speechRecognizer.continuous = false;
                speechRecognizer.interimResults = true;
                speechRecognizer.maxAlternatives = 3;
                speechRecognizer.start();
            } catch (error) {
                recognitionStarting = false;
                stopVoiceListening();
                const name = error && error.name;
                let msg;
                if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
                    msg = appState.currentLanguage === 'te'
                        ? 'మైక్ అనుమతి నిరాకరించబడింది. Chrome Site settings → Microphone → Allow ఎంచుకోండి.'
                        : 'Microphone permission denied. In Chrome, open Site settings → Microphone → Allow.';
                } else if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
                    msg = appState.currentLanguage === 'te' ? 'మైక్రోఫోన్ కనబడలేదు. పరికర మైక్‌ను తనిఖీ చేయండి.' : 'No microphone found. Check your device microphone.';
                } else if (name === 'NotReadableError' || name === 'TrackStartError') {
                    msg = appState.currentLanguage === 'te' ? 'మైక్‌ను మరో యాప్ ఉపయోగిస్తోంది. ఆ యాప్‌ను మూసి మళ్లీ ప్రయత్నించండి.' : 'Microphone is busy in another app. Close that app and retry.';
                } else {
                    msg = appState.currentLanguage === 'te'
                        ? 'మైక్ ప్రారంభం కాలేదు. HTTPSలో Chrome ఉపయోగించి మళ్లీ ప్రయత్నించండి.'
                        : 'Could not start microphone. Use updated Chrome on the HTTPS website and retry.';
                }
                showMicMessage(msg, true);
            }
        }

        function stopVoiceListening() {
            appState.isListening = false;
            document.getElementById('voice-mic').classList.remove('active-pulse');
            document.getElementById('voice-dock-btn').classList.remove('listening');
            if (micStatusDot()) micStatusDot().textContent = '🟢';
            if (micStatusLabel()) micStatusLabel().textContent = appState.currentLanguage === 'te'
                ? 'VOICE READY // మాట్లాడండి'
                : 'VOICE READY // SPEAK NOW';
        }

        function toggleVoiceAssistant() {
            toggleSpeechRecognition();
        }

        // Keep the selected language in the UI and speak the confirmation without
        // writing the confirmation sentence into the transcript area.
        function setLanguage(lang) {
            appState.currentLanguage = lang;
            const enButton = document.getElementById('lang-en');
            const teButton = document.getElementById('lang-te');
            const reportLang = document.getElementById('report-lang-meta');
            if (enButton) enButton.classList.toggle('active', lang === 'en');
            if (teButton) teButton.classList.toggle('active', lang === 'te');
            if (reportLang) reportLang.textContent = lang === 'te' ? 'తెలుగు (Telugu)' : 'English';

            speakTextInLanguage(
                lang === 'te' ? 'తెలుగు భాష ఎంపిక చేయబడింది. సిద్ధంగా ఉంది.' : 'English language selected. Ready.',
                lang === 'te' ? 'te-IN' : 'en-IN'
            );
        }

        // Google Translate TTS is used only as a fallback when the device has no
        // Telugu voice. It does not require installing a Telugu system voice.
        let fallbackAudio = null;
        function stopVoiceOutput() {
            if (window.speechSynthesis) window.speechSynthesis.cancel();
            if (fallbackAudio) {
                fallbackAudio.pause();
                fallbackAudio.currentTime = 0;
                fallbackAudio = null;
            }
        }

        function playTeluguAudioFallback(text) {
            try {
                stopVoiceOutput();
                const url = 'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=te&q=' + encodeURIComponent(String(text));
                fallbackAudio = new Audio(url);
                fallbackAudio.preload = 'auto';
                fallbackAudio.volume = 1;
                fallbackAudio.play().catch(() => {
                    // Browser/network restrictions may block remote audio playback.
                    // Do not put a diagnostic sentence in the visible transcript.
                });
            } catch (error) {
                // Keep the interface unchanged if remote audio is unavailable.
            }
        }

        function speakTextInLanguage(text, languageTag) {
            if (!appState.ttsEnabled) return;
            const isTelugu = /^te/i.test(languageTag);
            const synthAvailable = ('speechSynthesis' in window) && ('SpeechSynthesisUtterance' in window);
            const voices = synthAvailable ? refreshSpeechVoices() : [];
            const teluguVoice = voices.find(v => /^te([-_]|$)/i.test(v.lang) || /telugu/i.test(v.name));

            if (isTelugu && !teluguVoice) {
                playTeluguAudioFallback(text);
                return;
            }
            if (!synthAvailable) {
                if (isTelugu) playTeluguAudioFallback(text);
                return;
            }

            stopVoiceOutput();
            const utterance = new SpeechSynthesisUtterance(String(text));
            utterance.lang = languageTag;
            utterance.rate = 0.92;
            utterance.pitch = 1;
            utterance.volume = 1;
            const voice = isTelugu ? teluguVoice :
                (voices.find(v => /^en-IN$/i.test(v.lang)) ||
                 voices.find(v => /^en-GB$/i.test(v.lang)) ||
                 voices.find(v => /^en-US$/i.test(v.lang)) ||
                 voices.find(v => /^en([-_]|$)/i.test(v.lang)));
            if (voice) {
                utterance.voice = voice;
                utterance.lang = voice.lang || languageTag;
            }
            utterance.onerror = () => {
                if (isTelugu) playTeluguAudioFallback(text);
            };
            try {
                window.speechSynthesis.resume();
                window.speechSynthesis.speak(utterance);
            } catch (error) {
                if (isTelugu) playTeluguAudioFallback(text);
            }
        }

        function toggleTTS() {
            appState.ttsEnabled = !appState.ttsEnabled;
            const btn = document.getElementById('tts-btn');
            const icon = document.getElementById('tts-icon');
            const lbl = document.getElementById('tts-label');

            if (appState.ttsEnabled) {
                if (btn) btn.classList.add('tts-active');
                if (icon) icon.textContent = '🔊';
                if (lbl) lbl.textContent = 'Voice Out: ON';
                speakText(appState.currentLanguage === 'te' ? 'వాయిస్ ప్రారంభించబడింది' : 'Voice feedback enabled');
            } else {
                if (btn) btn.classList.remove('tts-active');
                if (icon) icon.textContent = '🔇';
                if (lbl) lbl.textContent = 'Voice Out: OFF';
                stopVoiceOutput();
            }
        }

        // Load available system voices when the browser exposes them.
        let availableSpeechVoices = [];
        function refreshSpeechVoices() {
            if (!('speechSynthesis' in window)) return [];
            availableSpeechVoices = window.speechSynthesis.getVoices() || [];
            return availableSpeechVoices;
        }
        if ('speechSynthesis' in window) {
            refreshSpeechVoices();
            window.speechSynthesis.onvoiceschanged = refreshSpeechVoices;
        }

        function speakText(text) {
            if (!appState.ttsEnabled) return;
            speakTextInLanguage(String(text), appState.currentLanguage === 'te' ? 'te-IN' : 'en-IN');
        }

        function executeVoiceQuery(text) {
            document.getElementById('voice-quote').textContent = `"${text}"`;
            processVoiceCommand(text);
        }

        function simulateVoiceFallback() {
            const sample = appState.currentLanguage === 'te' 
                ? "నాకు 3 రోజులుగా జ్వరం మరియు తలనొప్పి ఉంది" 
                : "I have fever and chills for 3 days";
            document.getElementById('voice-quote').textContent = `"${sample}"`;
            processVoiceCommand(sample);
        }

        function processVoiceCommand(raw) {
            const text = String(raw || '').toLocaleLowerCase().replace(/[.,!?;:]/g, ' ').replace(/\s+/g, ' ').trim();
            if (!text) return;

            // Direct page navigation by voice. Page numbers match the existing website tabs.
            const navCommands = [
                { page: 1, words: ['symptom checker', 'multi screener', 'screener', 'లక్షణాల పరిశీలన', 'సింప్టమ్ చెకర్'] },
                { page: 2, words: ['health monitor', 'monitor', 'vitals', 'chart', 'హెల్త్ మానిటర్', 'మానిటర్', 'చార్ట్'] },
                { page: 3, words: ['pathology', 'medical reference', 'పాథాలజీ'] },
                { page: 4, words: ['care regimen', 'care plan', 'treatment plan', 'కేర్ రెజిమెన్', 'సంరక్షణ ప్రణాళిక'] },
                { page: 5, words: ['smart sos', 'emergency', 'ambulance', 'ఎమర్జెన్సీ', 'అత్యవసర'] },
                { page: 6, words: ['tech and portals', 'technology portal', 'portals', 'టెక్ అండ్ పోర్టల్స్'] },
                { page: 7, words: ['medical report', 'open report', 'report page', 'రిపోర్ట్'] },
                { page: 8, words: ['health hub', 'open home', 'home page', 'dashboard', 'హెల్త్ హబ్'] }
            ];
            const nav = navCommands.find(item => item.words.some(word => text.includes(word)));
            if (nav) {
                switchPage(nav.page);
                const labels = {1:'Symptom Checker',2:'Health Monitor',3:'Pathology',4:'Care Regimen',5:'Smart SOS',6:'Tech and Portals',7:'Report',8:'Health Hub'};
                const msg = appState.currentLanguage === 'te' ? labels[nav.page] + ' పేజీ తెరవబడింది.' : 'Opening ' + labels[nav.page] + '.';
                if (voiceQuote()) voiceQuote().textContent = '"' + msg + '"';
                speakText(msg);
                return;
            }

            if (text.includes('emergency') || text.includes('ambulance') || text.includes('108') || text.includes('112') || 
                text.includes('ఎమర్జెన్సీ') || text.includes('అత్యవసర') || text.includes('ఛాతీ నొప్పి') || text.includes('chest pain') ||
                text.includes('shortness of breath') || text.includes('శ్వాస ఆడటం లేదు')) {
                switchPage(5);
                speakText(appState.currentLanguage === 'te'
                    ? "అత్యవసర సహాయ పేజీ తెరవబడింది. దయచేసి వెంటనే 108 లేదా 112 కు కాల్ చేయండి."
                    : "Emergency mode triggered. Dial 108 or 112 immediately.");
                return;
            }

            if (text.includes('monitor') || text.includes('vitals') || text.includes('chart') || text.includes('మానిటర్') || text.includes('చార్ట్')) {
                switchPage(2);
                speakText(appState.currentLanguage === 'te' ? "7 రోజుల హెల్త్ మానిటర్ చూపబడుతోంది." : "Displaying 7-day health monitor.");
                return;
            }

            let matchedSymptom = null;
            if (text.includes('fever') || text.includes('chills') || text.includes('thermal') || text.includes('జ్వరం') || text.includes('చలి')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'fever');
            } else if (text.includes('cough') || text.includes('cold') || text.includes('rhinorrhea') || text.includes('దగ్గు') || text.includes('జలుబు')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'cough');
            } else if (text.includes('headache') || text.includes('head') || text.includes('తలనొప్పి') || text.includes('తల నొప్పి')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'headache');
            } else if (text.includes('migraine') || text.includes('మైగ్రేన్')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'migraine');
            } else if (text.includes('throat') || text.includes('sore throat') || text.includes('గొంతు నొప్పి')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'throat');
            } else if (text.includes('stomach') || text.includes('abdominal') || text.includes('కడుపు') || text.includes('అజీర్ణం')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'stomach');
            } else if (text.includes('diarrhea') || text.includes('విరేచనాలు')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'diarrhea');
            } else if (text.includes('reflux') || text.includes('gerd') || text.includes('heartburn') || text.includes('ఎసిడిటీ') || text.includes('మంట')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'gerd');
            } else if (text.includes('dizzy') || text.includes('vertigo') || text.includes('మైకం') || text.includes('తలతిరుగుడు')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'vertigo');
            } else if (text.includes('wheeze') || text.includes('breath') || text.includes('ఆయాసం') || text.includes('శ్వాస')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'wheeze');
            } else if (text.includes('palpitation') || text.includes('racing heart') || text.includes('గుండె దడ')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'palpitation');
            } else if (text.includes('lightheaded') || text.includes('faint') || text.includes('కళ్లు తిరగడం')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'lightheaded');
            } else if (text.includes('back') || text.includes('lumbosacral') || text.includes('నడుము')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'backpain');
            } else if (text.includes('joint') || text.includes('arthritis') || text.includes('కీళ్ల')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'joint');
            } else if (text.includes('shingles') || text.includes('burning eruption') || text.includes('పొక్కులు')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'shingles');
            } else if (text.includes('rash') || text.includes('allergy') || text.includes('దురద') || text.includes('దద్దుర్లు')) {
                matchedSymptom = allSymptoms.find(s => s.id === 'rash');
            }

            if (matchedSymptom) {
                chooseSymptom(matchedSymptom.name, matchedSymptom.emoji, matchedSymptom.category, matchedSymptom.telugu, null, matchedSymptom.id);
            }

            const daysMatch = text.match(/(\d+)\s*(days?|రోజులు)/i);
            if (daysMatch) {
                const d = Math.min(14, Math.max(1, parseInt(daysMatch[1], 10)));
                const slider = document.getElementById('days-range');
                if (slider) slider.value = d;
                adjustDays(d);
            }

            if (text.includes('severe') || text.includes('grade 3') || text.includes('తీవ్రమైన')) {
                chooseSeverity('Severe (Grade 3)', '😣');
            } else if (text.includes('critical') || text.includes('grade 4') || text.includes('అత్యవసరం')) {
                chooseSeverity('Critical (Grade 4)', '🚨');
            } else if (text.includes('mild') || text.includes('grade 1') || text.includes('తేలికపాటి')) {
                chooseSeverity('Mild (Grade 1)', '🙂');
            }

            if (matchedSymptom) {
                const spokenAck = appState.currentLanguage === 'te'
                    ? `${matchedSymptom.telugu} గుర్తించబడింది. ${appState.days} రోజుల కాలపరిమితి ఎంపిక చేయబడింది.`
                    : `Identified ${matchedSymptom.name} for ${appState.days} days. Screener updated.`;
                if (voiceQuote()) voiceQuote().textContent = '"' + spokenAck + '"';
                speakText(spokenAck);
                return;
            }

            const help = appState.currentLanguage === 'te'
                ? 'మీ మాట వినిపించింది, కానీ ఆదేశం గుర్తించలేకపోయాను. Symptom Checker, Health Monitor, Pathology, Care Regimen, Smart SOS, Tech and Portals, Report లేదా Health Hub అని చెప్పండి.'
                : 'I heard you, but could not match that command. Try saying: Open Symptom Checker, Health Monitor, Pathology, Care Regimen, Smart SOS, Tech and Portals, Report, or Health Hub. For symptoms, say I have a fever or I have a headache.';
            showMicMessage(help, false);
            speakText(help);
        }

        // 7-Day Chart
        function setChartMetric(metric) {
            appState.activeMetric = metric;
            document.querySelectorAll('.metric-btn').forEach(b => b.classList.remove('active-metric'));
            event.target.classList.add('active-metric');

            const labels = {
                temp: 'Body Temperature Trajectory (°F)',
                hr: 'Resting Cardiac Rhythm (BPM)',
                spo2: 'Peripheral Blood Oxygen Saturation (%)',
                symptom: 'Symptom Severity Composite Score (0-10)'
            };
            document.getElementById('chart-metric-title').textContent = labels[metric];
            renderHistoryChart();
        }

        function renderHistoryChart() {
            const chartCanvas = document.getElementById('history-chart-canvas');
            if (!chartCanvas) return;
            const cCtx = chartCanvas.getContext('2d');

            const rect = chartCanvas.getBoundingClientRect();
            chartCanvas.width = rect.width * window.devicePixelRatio;
            chartCanvas.height = 220 * window.devicePixelRatio;
            cCtx.scale(window.devicePixelRatio, window.devicePixelRatio);

            const width = rect.width;
            const height = 220;
            const padLeft = 45;
            const padRight = 30;
            const padTop = 25;
            const padBottom = 35;

            cCtx.clearRect(0, 0, width, height);

            const m = appState.activeMetric;
            let values = vitalsHistory.map(v => v[m]);
            let minVal = Math.min(...values);
            let maxVal = Math.max(...values);

            if (m === 'temp') { minVal = 97.5; maxVal = 102.0; }
            else if (m === 'hr') { minVal = 60; maxVal = 95; }
            else if (m === 'spo2') { minVal = 94; maxVal = 100; }
            else if (m === 'symptom') { minVal = 0; maxVal = 10; }

            const chartW = width - padLeft - padRight;
            const chartH = height - padTop - padBottom;

            cCtx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
            cCtx.lineWidth = 1;
            cCtx.font = '10px monospace';
            cCtx.fillStyle = '#64748b';

            for (let i = 0; i <= 4; i++) {
                const y = padTop + (chartH / 4) * i;
                const valLabel = (maxVal - (i / 4) * (maxVal - minVal)).toFixed(m === 'temp' ? 1 : 0);
                cCtx.beginPath();
                cCtx.moveTo(padLeft, y);
                cCtx.lineTo(width - padRight, y);
                cCtx.stroke();
                cCtx.fillText(valLabel, 10, y + 3);
            }

            const points = vitalsHistory.map((item, idx) => {
                const x = padLeft + (chartW / (vitalsHistory.length - 1)) * idx;
                const normalized = (item[m] - minVal) / (maxVal - minVal);
                const y = padTop + chartH - normalized * chartH;
                return { x, y, val: item[m], label: item.day };
            });

            const grad = cCtx.createLinearGradient(0, padTop, 0, height - padBottom);
            grad.addColorStop(0, 'rgba(6, 182, 212, 0.45)');
            grad.addColorStop(0.5, 'rgba(56, 189, 248, 0.2)');
            grad.addColorStop(1, 'rgba(6, 182, 212, 0.0)');

            cCtx.beginPath();
            cCtx.moveTo(points[0].x, points[0].y);
            for (let i = 0; i < points.length - 1; i++) {
                const xc = (points[i].x + points[i + 1].x) / 2;
                const yc = (points[i].y + points[i + 1].y) / 2;
                cCtx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
            }
            cCtx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
            cCtx.lineTo(points[points.length - 1].x, height - padBottom);
            cCtx.lineTo(points[0].x, height - padBottom);
            cCtx.closePath();
            cCtx.fillStyle = grad;
            cCtx.fill();

            cCtx.beginPath();
            cCtx.moveTo(points[0].x, points[0].y);
            for (let i = 0; i < points.length - 1; i++) {
                const xc = (points[i].x + points[i + 1].x) / 2;
                const yc = (points[i].y + points[i + 1].y) / 2;
                cCtx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
            }
            cCtx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
            cCtx.strokeStyle = '#06b6d4';
            cCtx.lineWidth = 3.5;
            cCtx.shadowColor = '#38bdf8';
            cCtx.shadowBlur = 14;
            cCtx.stroke();
            cCtx.shadowBlur = 0;

            points.forEach((p) => {
                cCtx.beginPath();
                cCtx.arc(p.x, p.y, 5.5, 0, Math.PI * 2);
                cCtx.fillStyle = '#ffffff';
                cCtx.fill();
                cCtx.strokeStyle = '#0284c7';
                cCtx.lineWidth = 2.5;
                cCtx.stroke();

                cCtx.fillStyle = '#94a3b8';
                cCtx.font = '10px monospace';
                cCtx.textAlign = 'center';
                cCtx.fillText(p.label, p.x, height - 10);
            });
        }

        const tbody = document.getElementById('vitals-table-body');
        tbody.innerHTML = vitalsHistory.map(row => `
            <tr>
                <td><strong>${row.day}</strong> <span style="color: #64748b; font-size: 0.76rem;">(${row.date})</span></td>
                <td><span class="badge-status badge-${row.status}">${row.temp}°F</span></td>
                <td>${row.hr} BPM</td>
                <td>${row.spo2}%</td>
                <td>${row.condition}</td>
                <td>${row.status === 'fever' ? '🔴 Active Pyrexia' : row.status === 'subfebrile' ? '🟡 Subfebrile' : '🟢 Stable'}</td>
            </tr>
        `).join('');

        function chooseSymptom(name, emoji, category, telugu, element, id) {
            appState.symptom = name;
            appState.symptomId = id || (allSymptoms.find(s => s.name === name) || {}).id || 'fever';
            appState.symptomEmoji = emoji;
            appState.symptomCategory = category.toUpperCase();
            if (telugu) appState.symptomTelugu = telugu;

            document.querySelectorAll('#wizard-step-1 .hud-card').forEach(c => c.classList.remove('selected'));
            if (element) {
                element.classList.add('selected');
            } else {
                renderSymptomCards(appState.selectedCategory);
            }
            document.getElementById('btn-next').disabled = false;
        }

        function adjustDays(val) {
            appState.days = parseInt(val, 10);
            document.getElementById('slider-days').innerHTML = `${val}<span>DAYS</span>`;

            const icon = document.getElementById('duration-icon');
            const pill = document.getElementById('duration-pill');
            const pillIcon = document.getElementById('pill-icon');
            const pillText = document.getElementById('pill-text');

            if (val <= 2) {
                icon.textContent = '⚡';
                pillIcon.textContent = '🟢';
                pillText.textContent = 'Acute Early Phase (1-2 Days)';
                pill.style.color = '#34d399';
            } else if (val <= 6) {
                icon.textContent = '⏳';
                pillIcon.textContent = '⚡';
                pillText.textContent = 'Subacute Progression (3-6 Days)';
                pill.style.color = '#38bdf8';
            } else if (val <= 10) {
                icon.textContent = '⚠️';
                pillIcon.textContent = '⚠️';
                pillText.textContent = 'Persistent Window (>1 Week)';
                pill.style.color = '#fbbf24';
            } else {
                icon.textContent = '🗓️';
                pillIcon.textContent = '🚨';
                pillText.textContent = 'Chronic / Prolonged Pattern (2+ Weeks)';
                pill.style.color = '#f43f5e';
            }
        }

        function chooseSeverity(name, emoji, element) {
            appState.severity = name;
            appState.severityEmoji = emoji;
            document.querySelectorAll('#wizard-step-3 .hud-card').forEach(c => c.classList.remove('selected'));
            if (element) element.classList.add('selected');
            document.getElementById('btn-next').disabled = false;
        }

        function navigateWizard(direction) {
            if (direction === 1 && appState.wizardStep === 3) {
                runBioScan();
                return;
            }

            const cur = document.getElementById(`wizard-step-${appState.wizardStep}`);
            appState.wizardStep += direction;
            const next = document.getElementById(`wizard-step-${appState.wizardStep}`);

            if (cur) cur.classList.remove('active');
            if (next) next.classList.add('active');

            updateWizardHUD();
        }

        function updateWizardHUD() {
            const step = appState.wizardStep;
            const btnBack = document.getElementById('btn-back');
            const btnNext = document.getElementById('btn-next');
            const desc = document.getElementById('step-descriptor');
            const pct = document.getElementById('step-pct');
            const fill = document.getElementById('progress-fill');
            const actions = document.getElementById('wizard-actions');

            if (step <= appState.wizardTotal) {
                actions.classList.remove('hide');
                btnBack.classList.toggle('hide', step === 1);

                const percent = Math.round((step / appState.wizardTotal) * 100);
                pct.textContent = `${percent}%`;
                fill.style.width = `${percent}%`;

                if (step === 1) {
                    desc.textContent = 'PHASE 01 // CATEGORY & VECTOR SELECTION';
                    btnNext.innerHTML = '<span>PROCEED</span> <span>→</span>';
                    btnNext.disabled = !appState.symptom;
                } else if (step === 2) {
                    desc.textContent = 'PHASE 02 // CHRONOLOGICAL WINDOW';
                    btnNext.innerHTML = '<span>PROCEED</span> <span>→</span>';
                    btnNext.disabled = false;
                } else if (step === 3) {
                    desc.textContent = 'PHASE 03 // FUNCTIONAL SEVERITY';
                    btnNext.innerHTML = '<span>EXECUTE BIO-SCAN & XAI</span> <span>⚡</span>';
                    btnNext.disabled = !appState.severity;
                }
            }
        }

        function runBioScan() {
            const s3 = document.getElementById('wizard-step-3');
            const scan = document.getElementById('wizard-step-scanning');
            const actions = document.getElementById('wizard-actions');

            s3.classList.remove('active');
            actions.classList.add('hide');
            scan.classList.add('active');

            setTimeout(() => document.getElementById('log-1').classList.add('active-log'), 300);
            setTimeout(() => document.getElementById('log-2').classList.add('active-log'), 900);
            setTimeout(() => document.getElementById('log-3').classList.add('active-log'), 1500);

            setTimeout(() => {
                scan.classList.remove('active');
                document.getElementById('wizard-step-assessment').classList.add('active');
                appState.wizardStep = 4;
                renderAssessmentResult();
            }, 2100);
        }

        function renderAssessmentResult() {
            document.getElementById('res-symptom').innerHTML = `${appState.symptomEmoji} ${appState.symptom} <small style="color:#38bdf8; margin-left:6px;">(${appState.symptomTelugu || ''})</small>`;
            document.getElementById('res-category').textContent = appState.symptomCategory || 'SYSTEMIC';
            document.getElementById('res-duration').textContent = `${appState.days} Day${appState.days > 1 ? 's' : ''}`;
            document.getElementById('res-severity').innerHTML = `${appState.severityEmoji} ${appState.severity}`;

            const beacon = document.getElementById('res-beacon');
            const panel = document.getElementById('res-directive-panel');
            const icon = document.getElementById('res-icon');
            const copy = document.getElementById('res-directive-copy');

            const isHigh = appState.severity.includes('Critical') || (appState.days >= 7 && appState.severity.includes('Severe'));
            const isMid = appState.severity.includes('Severe') || appState.days >= 6;

            document.getElementById('xai-vector-val').textContent = `${appState.symptomCategory} Path`;
            document.getElementById('xai-chrono-val').textContent = `${appState.days} Days (${appState.days <= 2 ? 'Acute' : appState.days <= 6 ? 'Subacute' : 'Persistent'})`;
            document.getElementById('xai-chrono-calc').textContent = `Trajectory Multiplier: +${appState.days * 6} pts`;

            let differentials = [];
            if (appState.symptom.includes('Fever') || appState.symptom.includes('Cough')) {
                differentials = [
                    { name: 'Viral Upper Respiratory Infection (URI)', prob: appState.days > 5 ? 40 : 68, color: '#38bdf8', rationale: 'Supported by subacute gradual onset, room air SpO2 (98%), normal resting HR.' },
                    { name: 'Seasonal Influenza / Viral Pyrexia', prob: appState.days > 5 ? 35 : 22, color: '#10b981', rationale: 'Congruent with thermal chills and Day -3 peak pyrexia (101.2°F).' },
                    { name: 'Secondary Bacterial Superinfection', prob: appState.days >= 7 ? 25 : 10, color: '#f59e0b', rationale: appState.days >= 7 ? 'Persistent duration >7 days significantly increases bacterial suspicion.' : 'Less likely due to defervescence trend.' }
                ];
            } else if (appState.symptom.includes('Headache') || appState.symptom.includes('Migraine')) {
                differentials = [
                    { name: 'Myofascial Tension-Type Cephalea', prob: 62, color: '#38bdf8', rationale: 'Band-like cranial pressure with cervical paraspinal fatigue.' },
                    { name: 'Vascular Cephalea / Migraine', prob: 28, color: '#8b5cf6', rationale: 'Unilateral pulsatile component aggravated by photic/acoustic stimuli.' },
                    { name: 'Sinus Congestion Headache', prob: 10, color: '#10b981', rationale: 'Secondary to pharyngeal or nasal mucosal edema.' }
                ];
            } else if (appState.symptom.includes('Stomach') || appState.symptom.includes('Diarrhea') || appState.symptom.includes('Reflux')) {
                differentials = [
                    { name: 'Acute Viral Gastroenteritis', prob: 65, color: '#38bdf8', rationale: 'Self-limiting enteric mucosal irritation with rapid onset.' },
                    { name: 'Functional Dyspepsia / Acid Pyrosis', prob: 25, color: '#f59e0b', rationale: 'Epigastric burn worsened post-prandially.' },
                    { name: 'Foodborne Toxin Hypersensitivity', prob: 10, color: '#10b981', rationale: 'Transient enteric hypermotility.' }
                ];
            } else {
                differentials = [
                    { name: `Primary ${appState.symptomCategory} Strain`, prob: 70, color: '#38bdf8', rationale: 'Etiology localized to primary organ category.' },
                    { name: 'Musculoskeletal Overuse Syndromic', prob: 20, color: '#10b981', rationale: 'Associated with postural fatigue or biomechanical torsion.' },
                    { name: 'Systemic Reactive Vector', prob: 10, color: '#8b5cf6', rationale: 'Mild metabolic or inflammatory response.' }
                ];
            }

            const diffContainer = document.getElementById('diff-bars-container');
            diffContainer.innerHTML = differentials.map(d => `
                <div class="diff-item">
                    <div class="diff-meta">
                        <span>${d.name}</span>
                        <span style="color: ${d.color}; font-family: var(--font-mono);">${d.prob}% Likelihood</span>
                    </div>
                    <div class="diff-bar-bg">
                        <div class="diff-bar-fill" style="width: ${d.prob}%; background: ${d.color};"></div>
                    </div>
                    <div class="diff-rationale">${d.rationale}</div>
                </div>
            `).join('');

            if (isHigh) {
                beacon.className = 'triage-beacon triage-urgent';
                beacon.textContent = 'HIGH CLINICAL PRIORITY';
                icon.textContent = '🚨';
                panel.style.borderColor = 'rgba(244, 63, 94, 0.4)';
                copy.innerHTML = `<strong>Physician Evaluation Warranted:</strong> Duration (${appState.days} days) in ${appState.symptomCategory} combined with severe functional impairment requires urgent clinic review or telehealth consult.`;
                
                speakText(appState.currentLanguage === 'te' 
                    ? "హెచ్చరిక: అధిక ప్రాధాన్యత. దయచేసి వెంటనే వైద్యుడిని సంప్రదించండి లేదా అత్యవసర విభాగాన్ని సందర్శించండి."
                    : "High clinical priority detected. Physician evaluation or urgent outpatient review is recommended.");
            } else if (isMid) {
                beacon.className = 'triage-beacon triage-mid';
                beacon.textContent = 'MODERATE ATTENTION';
                icon.textContent = '⚠️';
                panel.style.borderColor = 'rgba(245, 158, 11, 0.4)';
                copy.innerHTML = `<strong>Surveillance Protocol:</strong> Maintain vital tracking. If symptoms persist beyond 48 hours without relief, schedule an outpatient physician visit.`;
                
                speakText(appState.currentLanguage === 'te'
                    ? "మధ్యస్థ స్థాయి. లక్షణాలను పర్యవేక్షించండి మరియు తగిన విశ్రాంతి తీసుకోండి."
                    : "Moderate surveillance protocol. Maintain hydration and monitoring.");
            } else {
                beacon.className = 'triage-beacon triage-low';
                beacon.textContent = 'LOW RISK CARE';
                icon.textContent = '💡';
                panel.style.borderColor = 'rgba(16, 185, 129, 0.4)';
                copy.innerHTML = `<strong>Supportive Self-Care:</strong> Presentation aligns with standard mild acute episodes. Prioritize oral hydration, rest, and routine symptomatic relief as indicated.`;
                
                speakText(appState.currentLanguage === 'te'
                    ? "తక్కువ ప్రమాదం. విశ్రాంతి మరియు పుష్కలంగా నీరు త్రాగడం ద్వారా నయం కావచ్చు."
                    : "Low risk presentation. Prioritize oral hydration and rest.");
            }
        }

        function simulateWhatIf(scenario) {
            const note = document.getElementById('what-if-note');
            note.style.display = 'block';

            if (scenario === 'duration_7') {
                note.innerHTML = `
                    <strong style="color: #fbbf24;">Simulated Scenario (Timeline = 7+ Days):</strong><br>
                    Extending duration past 7 consecutive days escalates Triage from <em>Low/Moderate</em> to <strong>Moderate/High Attention</strong>. Differential likelihood for <em>Secondary Bacterial Superinfection</em> increases from 10% to <strong>35%</strong>. Clinical recommendation: Schedule outpatient physician auscultation.
                `;
            } else if (scenario === 'hypoxia') {
                note.innerHTML = `
                    <strong style="color: #f43f5e;">Simulated Scenario (SpO2 drops to 92%):</strong><br>
                    Critical Red Flag Triggered! Resting oxygen below 95% indicates compromised alveolar gas exchange. Triage flips immediately to <strong>CRITICAL EMERGENCY</strong>. Action: Dial <strong>108 / 112</strong> or proceed to nearest emergency trauma department.
                `;
            } else if (scenario === 'stiff_neck') {
                note.innerHTML = `
                    <strong style="color: #f43f5e;">Simulated Scenario (Accompanied by Nuchal Rigidity):</strong><br>
                    Severe Red Flag: Fever + Rigid Neck Stiffness raises acute concern for Meningeal Irritation. Algorithm triggers immediate emergency department notification and lumbar evaluation alert.
                `;
            } else if (scenario === 'resolved') {
                note.innerHTML = `
                    <strong style="color: #34d399;">Simulated Scenario (Temperature Normalizes):</strong><br>
                    Favorable Defervescence. Telemetry confirms resolution of pyrexia. Recommendation: Transition to maintenance convalescence and gradual return to physical activity.
                `;
            }
        }

        function resetWizard() {
            appState.wizardStep = 1;
            document.querySelectorAll('#wizard-step-1 .hud-card').forEach(c => c.classList.remove('selected'));
            document.querySelectorAll('.hud-log-line').forEach(l => l.classList.remove('active-log'));

            document.getElementById('wizard-step-assessment').classList.remove('active');
            document.getElementById('wizard-step-1').classList.add('active');
            updateWizardHUD();
        }

        function toggleMed(el) {
            el.classList.toggle('checked');
        }

        let glassesDrunk = 5;
        function toggleGlass(el) {
            el.classList.toggle('drank');
            glassesDrunk = document.querySelectorAll('.water-glass-icon.drank').length;
            const ml = glassesDrunk * 250;
            document.getElementById('hydration-count').innerHTML = `${glassesDrunk} / 8 <span style="font-size: 0.9rem; color: var(--text-dim); font-family: sans-serif;">GLASSES (${ml.toLocaleString()} mL)</span>`;
        }

        function findNearestHospitals() {
            const statusEl = document.getElementById('geo-status-text');
            if (!navigator.geolocation) {
                window.open('https://www.google.com/maps/search/emergency+hospital+near+me', '_blank');
                return;
            }

            statusEl.textContent = "Acquiring GPS fix... searching nearest 24/7 Trauma Centers...";
            navigator.geolocation.getCurrentPosition(
                (pos) => {
                    const lat = pos.coords.latitude;
                    const lng = pos.coords.longitude;
                    statusEl.innerHTML = `GPS Coordinates Locked: <strong>${lat.toFixed(4)}°N, ${lng.toFixed(4)}°E</strong>. Opening Google Maps Navigation...`;
                    window.open(`https://www.google.com/maps/search/emergency+hospital/@${lat},${lng},14z`, '_blank');
                },
                (err) => {
                    statusEl.textContent = "GPS prompt bypassed. Redirecting to regional emergency room lookup...";
                    window.open('https://www.google.com/maps/search/emergency+hospital+near+me', '_blank');
                },
                { timeout: 7000 }
            );
        }

        // ========================================================
        // COMPLETE CLINICAL PROTOCOL MATRIX (ALL 16 SYMPTOMS)
        // ========================================================
        const symptomClinicalKnowledge = {
            'fever': {
                medicines: [
                    { name: 'Paracetamol / Acetaminophen (650mg)', dose: '1 tablet every 6–8 hours as needed (Max 2600mg/day)', purpose: 'Antipyretic for thermal pyrexia reduction and systemic myalgia relief' },
                    { name: 'WHO Formula Oral Rehydration Salts (ORS)', dose: '1 packet in 1000 mL boiled & cooled water sipped throughout day', purpose: 'Restores essential sodium & potassium electrolytes depleted by sweating' },
                    { name: 'Vitamin C (500mg) + Elemental Zinc (50mg)', dose: '1 tablet once daily post meal for 7 days', purpose: 'Immunological cellular cofactors supporting viral convalescence' }
                ],
                checkups: [
                    { test: 'Complete Blood Count (CBC) + Platelet Count & ESR', urgency: 'Within 24–48 Hours', note: 'Assesses total leukocyte shift, hematocrit, and thrombocytopenia status' },
                    { test: 'Dengue NS1 Antigen & IgM/IgG Dual Antibody Test', urgency: 'If fever > Day 3', note: 'Detects endemic arboviral envelope antigen in acute febrile window' },
                    { test: 'Typhidot / Widal Screen & Peripheral Smear for Malarial Parasite', urgency: 'Day 3 to 5', note: 'Excludes enteric Salmonella bacteremia and intraerythrocytic Plasmodium' },
                    { test: 'Complete Urine Examination (CUE Routine)', urgency: 'Routine', note: 'Rules out occult cystitis or upper urinary tract focal infection' }
                ],
                hospitals: {
                    dept: 'Department of Internal Medicine & Infectious Diseases',
                    names: 'Apollo Hospitals • Fortis Healthcare • All India Institute of Medical Sciences (AIIMS) • District Civil Hospital',
                    type: 'Multi-Specialty Secondary/Tertiary Referral Hospital with Active Fever OPD',
                    query: 'hospital+internal+medicine+fever+near+me'
                }
            },
            'cough': {
                medicines: [
                    { name: 'Dextromethorphan + Chlorpheniramine Maleate Syrup', dose: '5 mL to 10 mL thrice daily post meals for 5 days', purpose: 'Centrally-acting antitussive and H1 antagonist suppressing dry nocturnal cough' },
                    { name: 'Hypertonic Warm Saline Gargle Solution', dose: 'Gargle 3 times daily for 3 minutes', purpose: 'Reduces pharyngeal mucosal edema and clears tenacious mucus plaques' },
                    { name: 'Levocetirizine (5mg) + Montelukast (10mg)', dose: '1 tablet once daily at bedtime for 5 days', purpose: 'Bronchial leukotriene inhibition and airway anti-inflammatory' }
                ],
                checkups: [
                    { test: 'Digital Chest X-Ray (Postero-Anterior View)', urgency: 'Prompt (within 48 hrs)', note: 'Evaluates for consolidation, bronchopneumonia, or atypical interstitial infiltrates' },
                    { test: 'High-Sensitivity C-Reactive Protein (hs-CRP)', urgency: 'Routine', note: 'Differentiates viral bronchitis from invasive bacterial pneumonitis' },
                    { test: 'Sputum Gram Stain & Pathogenic Culture Sensitivity', urgency: 'If productive > 5 days', note: 'Identifies microbial pathogens and guides targeted antibiotic therapy' }
                ],
                hospitals: {
                    dept: 'Department of Pulmonology & Respiratory Medicine',
                    names: 'Max Super Speciality Hospital • Yashoda Pulmonary Institute • National Institute of TB and Chest Diseases • Apollo Chest Wing',
                    type: 'Pulmonology Outpatient & Diagnostic Bronchoscopy Suite',
                    query: 'pulmonologist+chest+hospital+near+me'
                }
            },
            'throat': {
                medicines: [
                    { name: 'Povidone-Iodine (1% w/v) / Chlorhexidine Gargle', dose: '10 mL diluted in equal parts warm water, gargle 3 times daily', purpose: 'Broad-spectrum microbicidal topical action against pharyngeal pathogens' },
                    { name: 'Flurbiprofen (8.75mg) Anti-inflammatory Lozenges', dose: 'Dissolve 1 lozenge slowly in mouth every 3–6 hours', purpose: 'Rapid localized NSAID odynophagia relief and tonsillar soothing' },
                    { name: 'Paracetamol (500mg) or Ibuprofen (400mg)', dose: '1 tablet after food as needed for severe dysphagia', purpose: 'Systemic analgesia reducing pain during deglutition' }
                ],
                checkups: [
                    { test: 'Rapid Antigen Detection Test (RADT) for Group A Strep', urgency: 'Prompt', note: 'Rules out Streptococcus pyogenes pharyngitis to prevent post-streptococcal sequelae' },
                    { test: 'Throat Swab Bacterial & Fungal Culture', urgency: 'Within 48 hours', note: 'Identifies causative pathogens if exudative tonsillitis is visualised' },
                    { test: 'Complete Hemogram (CBC)', urgency: 'Routine', note: 'Assesses neutrophil count and absolute lymphocytic response' }
                ],
                hospitals: {
                    dept: 'Department of Otolaryngology (ENT - Head & Neck Surgery)',
                    names: 'Apollo ENT Care • Manipal ENT Specialty Clinic • KIMS ENT Department • Regional Government ENT Hospital',
                    type: 'Otolaryngology Diagnostic Clinic with Video Laryngoscopy',
                    query: 'ENT+ear+nose+throat+hospital+near+me'
                }
            },
            'wheeze': {
                medicines: [
                    { name: 'Levosalbutamol (1.25mg) + Ipratropium (500mcg) Respules', dose: 'Nebulize with 2.5 mL normal saline every 6–8 hours SOS', purpose: 'Dual beta-2 adrenergic & anticholinergic rapid bronchodilation' },
                    { name: 'Budesonide (0.5mg) Nebulizing Suspension', dose: 'Nebulize twice daily for 5 days', purpose: 'Potent topical airway corticosteroid targeting bronchial edema' },
                    { name: 'Acebrophylline (100mg) Capsules', dose: '1 capsule twice daily after meals', purpose: 'Mucolytic surfactant regulator and sustained airway relaxant' }
                ],
                checkups: [
                    { test: 'Pulmonary Function Test (Spirometry / Pre & Post Bronchodilator)', urgency: 'Semi-urgent', note: 'Objectively grades FEV1/FVC ratio and assesses airway reversibility' },
                    { test: 'High-Resolution Computed Tomography of Chest (HRCT)', urgency: 'Within 48 hours', note: 'Excludes bronchiectasis, small airway trapping, and atelectasis' },
                    { test: 'Arterial Blood Gas Analysis (ABG) & Pulse Oximetry', urgency: 'Immediate if SpO2 < 94%', note: 'Quantifies arterial pO2, pCO2, and systemic oxygen tension' }
                ],
                hospitals: {
                    dept: 'Department of Pulmonary Medicine, Allergy & Critical Care',
                    names: 'Medanta Respiratory Institute • Apollo Pulmonary Critical Care • Fortis Thoracic Center • Civil Chest Hospital',
                    type: 'Tertiary Respiratory Care Center with Dedicated High-Flow Oxygen & ICU',
                    query: 'pulmonology+chest+hospital+near+me'
                }
            },
            'headache': {
                medicines: [
                    { name: 'Naproxen Sodium (250mg) + Paracetamol (500mg)', dose: '1 tablet with full glass of water with food; max 2/day', purpose: 'Combined peripheral prostaglandin inhibition for myofascial cranial tension' },
                    { name: 'Magnesium Glycinate (400mg)', dose: '1 tablet at bedtime', purpose: 'Neuromuscular cranial relaxation and central threshold stabilization' },
                    { name: 'Menthol & Camphor Topical Relief Balm', dose: 'Apply gentle circular pressure over bilateral temples', purpose: 'Cutaneous counter-irritation targeting trigeminal nociceptors' }
                ],
                checkups: [
                    { test: 'Ambulatory Blood Pressure Profiling (Serial 24-hr BP)', urgency: 'Immediate', note: 'Excludes malignant or labile intracranial-transmitting hypertension' },
                    { test: 'Ophthalmoscopy / Dilated Fundus Examination', urgency: 'Within 48 hours', note: 'Inspects optic nerve disc margin to rule out raised intracranial pressure (papilledema)' },
                    { test: 'Non-Contrast Computed Tomography of Brain (NCCT Head)', urgency: 'Urgent if worst headache or focal deficit', note: 'Excludes subarachnoid hemorrhage, mass lesions, and acute intracranial pathology' }
                ],
                hospitals: {
                    dept: 'Department of Neurology & Neurosciences',
                    names: 'NIMHANS • CARE Institute of Neurosciences • Max Neuro Hospital • Sir Ganga Ram Hospital',
                    type: 'Advanced Neurological Evaluation Facility with 24/7 CT/MRI Neuro-Imaging',
                    query: 'neurology+hospital+near+me'
                }
            },
            'migraine': {
                medicines: [
                    { name: 'Rizatriptan (10mg) or Sumatriptan (50mg)', dose: '1 tablet taken at earliest onset of migraine aura; max 20mg/24hr', purpose: 'Selective cranial 5-HT1B/1D agonist reversing meningeal vasodilation' },
                    { name: 'Domperidone (10mg) or Ondansetron (4mg)', dose: '1 tablet 15 minutes prior to triptan/analgesic', purpose: 'Antiemetic reversing migraine-induced gastric hypomotility' },
                    { name: 'Naproxen Sodium (500mg)', dose: 'Co-administered with triptan for sustained relief', purpose: 'Suppresses neurogenic inflammation and central sensitization' }
                ],
                checkups: [
                    { test: 'Magnetic Resonance Imaging of Brain (MRI Head with Contrast)', urgency: 'Semi-urgent', note: 'Rules out structural lesions, arteriovenous malformations (AVM), or dural sinus thrombosis' },
                    { test: 'Comprehensive Ophthalmologic & Refraction Exam', urgency: 'Routine', note: 'Assesses optical refractive errors and visual triggers' }
                ],
                hospitals: {
                    dept: 'Comprehensive Headache & Neuro-Vascular Clinic',
                    names: 'Apollo Institute of Neurosciences • Fortis Neuro Center • Aster Medcity • AIIMS',
                    type: 'Specialized Headache Clinic & Neuro-Electrophysiology Laboratory',
                    query: 'headache+migraine+neurologist+near+me'
                }
            },
            'vertigo': {
                medicines: [
                    { name: 'Betahistine Dihydrochloride (16mg)', dose: '1 tablet thrice daily with food for 10 days', purpose: 'H1 agonist and H3 antagonist improving microcirculation in labyrinthine stria vascularis' },
                    { name: 'Cinnarizine (25mg) or Dimenhydrinate (50mg)', dose: '1 tablet as needed for severe acute rotational vertigo', purpose: 'Labyrinthine sedative suppressing vestibular nuclear firing' },
                    { name: 'Ginkgo Biloba Extract (120mg)', dose: '1 tablet twice daily', purpose: 'Supports inner ear and vertebrobasilar arterial perfusion' }
                ],
                checkups: [
                    { test: 'Dix-Hallpike & Epley Diagnostic Positional Nystagmus Maneuver', urgency: 'Immediate in clinic', note: 'Diagnoses posterior canal benign paroxysmal positional vertigo (BPPV)' },
                    { test: 'Pure Tone Audiometry (PTA) & Tympanometry', urgency: 'Routine', note: 'Assesses endolymphatic hydrops and cochlear sensorineural hearing thresholds' },
                    { test: 'Magnetic Resonance Angiography (MRA) of Vertebrobasilar System', urgency: 'If atypical or associated with ataxia', note: 'Rules out vertebrobasilar insufficiency and posterior fossa ischemia' }
                ],
                hospitals: {
                    dept: 'Vestibular & Neuro-Otology Specialty Clinic',
                    names: 'Manipal Vestibular Rehabilitation Center • Apollo Neuro-Otology • PGIMER • Sir H. N. Reliance Hospital',
                    type: 'Specialized Balance Center with Videonystagmography (VNG) Suite',
                    query: 'vertigo+balance+clinic+hospital+near+me'
                }
            },
            'stomach': {
                medicines: [
                    { name: 'Pantoprazole (40mg) + Domperidone (30mg SR)', dose: '1 capsule 30 minutes before breakfast daily for 14 days', purpose: 'Dual proton pump inhibitor and gastroprokinetic reducing gastric acid hypersecretion' },
                    { name: 'Dicyclomine (10mg) + Paracetamol (325mg)', dose: '1 tablet as needed for severe visceral colicky cramps', purpose: 'Antispasmodic smooth muscle relaxant targeting enteric spasm' },
                    { name: 'Magaldrate + Simethicone Oral Gel Suspension', dose: '10 mL two hours after meals and at bedtime', purpose: 'Rapid chemical acid neutralization and gastric gas bubble coalescence' }
                ],
                checkups: [
                    { test: 'Upper Gastrointestinal Endoscopy (Esophagogastroduodenoscopy - EGD)', urgency: 'If refractory > 2 weeks', note: 'Visual inspection for peptic ulcer, mucosal erosions, and duodenitis' },
                    { test: 'High-Resolution Ultrasound of Whole Abdomen & Pelvis', urgency: 'Within 48 hours', note: 'Excludes cholelithiasis, biliary sludge, pancreatitis, and appendiceal signs' },
                    { test: 'Helicobacter pylori Fecal Antigen / Urea Breath Test', urgency: 'Routine', note: 'Identifies gastric bacterial colonization requiring eradication protocol' }
                ],
                hospitals: {
                    dept: 'Department of Medical Gastroenterology & Hepatology',
                    names: 'Asian Institute of Gastroenterology (AIG) • Apollo Digestive Diseases Center • Fortis Escorts Gastric Care',
                    type: 'Advanced Gastroenterology Center with 24/7 Therapeutic Endoscopy Suite',
                    query: 'gastroenterologist+digestive+hospital+near+me'
                }
            },
            'diarrhea': {
                medicines: [
                    { name: 'WHO Formula Oral Rehydration Salts (ORS)', dose: 'Sip 200–300 mL after every loose watery motion', purpose: 'Prevents acute hypovolemic dehydration and acidosis via sodium-glucose transport' },
                    { name: 'Racecadotril (100mg) Capsules', dose: '1 capsule thrice daily before meals for 3 days', purpose: 'Enkephalinase inhibitor reducing intestinal hypersecretion without slowing motility' },
                    { name: 'Saccharomyces boulardii (250mg) Probiotic Sachets', dose: '1 sachet twice daily in lukewarm water or yogurt', purpose: 'Restores enteric gut microbiota and neutralizes microbial exotoxins' }
                ],
                checkups: [
                    { test: 'Stool Routine, Microscopy & Occult Blood', urgency: 'Immediate (within 24 hrs)', note: 'Detects fecal leukocytes, red cells, protozoal cysts, and invasive trophozoites' },
                    { test: 'Serum Electrolytes (Sodium, Potassium, Chloride, Bicarbonate)', urgency: 'Prompt if fatigue or vomiting', note: 'Evaluates for hypokalemia, hyponatremia, and metabolic contraction alkalosis' },
                    { test: 'Stool Pathogen Multiplex PCR / Culture', urgency: 'If persistent > 3 days', note: 'Isolates enterotoxigenic bacterial strains and guides targeted antimicrobial choices' }
                ],
                hospitals: {
                    dept: 'Department of Gastroenterology & Tropical Infectious Diseases',
                    names: 'Christian Medical College (CMC) • AIG Hospitals • Apollo Emergency & Gastro Wing • Kasturba Hospital',
                    type: 'Specialized Enteric Disease Clinic & Dehydration Observation Unit',
                    query: 'gastroenterology+infectious+diseases+hospital+near+me'
                }
            },
            'gerd': {
                medicines: [
                    { name: 'Esomeprazole (40mg) Capsules', dose: '1 capsule 30 minutes before first meal daily for 4 weeks', purpose: 'Potent gastric H+/K+-ATPase suppression allowing mucosal healing' },
                    { name: 'Sodium Alginate + Sodium Bicarbonate Suspension', dose: '10 mL after meals and at bedtime', purpose: 'Forms a physical buoyant viscous raft barrier atop gastric pocket' },
                    { name: 'Itopride Hydrochloride (50mg)', dose: '1 tablet thrice daily before food', purpose: 'Prokinetic enhancing lower esophageal sphincter tone and gastric emptying' }
                ],
                checkups: [
                    { test: 'Diagnostic Upper GI Endoscopy with Biopsy', urgency: 'Elective', note: 'Grades Los Angeles classification of reflux esophagitis and excludes Barrett mucosa' },
                    { test: '24-Hour Ambulatory Esophageal pH-Impedance Monitoring', urgency: 'If refractory', note: 'Quantifies acidic and non-acidic bolus exposure throughout circadian cycle' }
                ],
                hospitals: {
                    dept: 'Esophageal & Acid-Peptic Specialty Clinic',
                    names: 'AIG Hospitals • Apollo Institute of Gastric Sciences • Max Digestive Institute • Sir Ganga Ram',
                    type: 'Dedicated Esophageal Motility & High-Resolution Manometry Unit',
                    query: 'gerd+acid+reflux+gastroenterologist+near+me'
                }
            },
            'palpitation': {
                medicines: [
                    { name: 'Propranolol (20mg) or Metoprolol Tartrate (25mg)', dose: 'Under physician guidance only; 1 tablet morning SOS', purpose: 'Selective beta-1 adrenergic blockade dampening sinus tachycardia and autonomic surge' },
                    { name: 'Oral Magnesium Orotate / Taurate (500mg)', dose: '1 tablet daily with meals', purpose: 'Cardiac cellular electrolyte cofactor stabilizing myocyte resting potentials' }
                ],
                checkups: [
                    { test: '12-Lead Electrocardiogram (ECG) with Rhythm Strip', urgency: 'Immediate', note: 'Assesses PR interval, QTc prolongation, pre-excitation (WPW), and ectopic beats' },
                    { test: 'Serum Thyroid Profile (Free T3, Free T4, Ultrasensitive TSH)', urgency: 'Routine', note: 'Excludes thyrotoxicosis and hyperthyroidism-induced hyperdynamic circulation' },
                    { test: '24-Hour to 48-Hour Ambulatory Holter Monitor', urgency: 'Within 72 hours', note: 'Correlates patient symptoms with true electrophysiological arrhythmogenic events' },
                    { test: '2D Transthoracic Echocardiogram (Echo)', urgency: 'Semi-urgent', note: 'Evaluates left ventricular ejection fraction, valve morphology, and chamber diameters' }
                ],
                hospitals: {
                    dept: 'Department of Cardiology & Cardiac Electrophysiology',
                    names: 'Narayana Health • Asian Heart Institute • Fortis Escorts Heart Institute • Apollo Cardiology Wing',
                    type: 'Tertiary Cardiac Center with Dedicated EP Lab and Cardiac Care Unit (CCU)',
                    query: 'cardiologist+heart+hospital+near+me'
                }
            },
            'lightheaded': {
                medicines: [
                    { name: 'Oral Electrolyte Replacement Hydration', dose: '1 liter water with balanced mineral formula daily', purpose: 'Expands intravascular plasma volume and supports venous return' },
                    { name: 'Fludrocortisone Acetate (0.1mg)', dose: 'Prescription only under specialist guidance', purpose: 'Mineralocorticoid promoting renal sodium reabsorption in orthostatic hypotension' }
                ],
                checkups: [
                    { test: 'Orthostatic Vitals Recording (Lying, Sitting, 3-min Standing BP/HR)', urgency: 'Immediate in clinic', note: 'Confirms postural drop (SBP >20 mmHg or DBP >10 mmHg) or POTS tachycardia' },
                    { test: 'Serum Electrolytes, Fasting Blood Glucose & HbA1c', urgency: 'Routine', note: 'Excludes hypoglycemia, hypovolemia, and diabetic autonomic neuropathy' },
                    { test: 'Head-Up Tilt Table Test (HUTT)', urgency: 'If recurrent near-syncope', note: 'Distinguishes vasovagal neurocardiogenic syncope from autonomic failure' }
                ],
                hospitals: {
                    dept: 'Department of General Medicine & Autonomic Clinic',
                    names: 'Apollo Hospitals • Fortis Healthcare • Max Hospital • AIIMS',
                    type: 'Comprehensive Internal Medicine & Syncope Diagnostic Facility',
                    query: 'internal+medicine+hospital+near+me'
                }
            },
            'backpain': {
                medicines: [
                    { name: 'Aceclofenac (100mg) + Paracetamol (325mg) + Thiocolchicoside (4mg)', dose: '1 tablet twice daily after meals for 5 days', purpose: 'Combined NSAID analgesia with GABAmimetic central muscle relaxation' },
                    { name: 'Pregabalin (75mg) + Methylcobalamin (1500mcg)', dose: '1 capsule at bedtime if radicular sciatic symptoms present', purpose: 'Alpha-2-delta calcium subunit ligand calming neuropathic nerve irritation' },
                    { name: 'Diclofenac Diethylamine Topical Gel', dose: 'Gentle topical application over lumbar area 3 times daily', purpose: 'Direct transdermal NSAID absorption minimizing gastrointestinal toxicity' }
                ],
                checkups: [
                    { test: 'Digital X-Ray of Lumbosacral Spine (AP & Lateral Views)', urgency: 'Within 48 hours', note: 'Evaluates vertebral alignment, disk height reduction, and spondylolisthesis' },
                    { test: 'Magnetic Resonance Imaging of LS Spine (MRI Spine)', urgency: 'Urgent if neurological deficit / foot drop', note: 'Visualizes disk herniation, thecal sac compression, and nerve root impingement' },
                    { test: 'Electromyography & Nerve Conduction Study (EMG/NCV)', urgency: 'If radiculopathy > 3 weeks', note: 'Quantifies functional nerve root denervation and conduction delay' }
                ],
                hospitals: {
                    dept: 'Department of Orthopedics & Spine Surgery',
                    names: 'Indian Spinal Injuries Centre • Apollo Spine Institute • Shalby Orthopedics • Ganga Hospital',
                    type: 'Super-Specialty Orthopedic & Spine Surgery Institute with Physiotherapy Wing',
                    query: 'orthopedic+spine+hospital+near+me'
                }
            },
            'joint': {
                medicines: [
                    { name: 'Etoricoxib (90mg)', dose: '1 tablet once daily after meals for 7 days', purpose: 'Selective COX-2 inhibitor with superior gastric safety for acute arthralgia' },
                    { name: 'Glucosamine Sulfate (1500mg) + Chondroitin (1200mg)', dose: '1 tablet daily with meals', purpose: 'Glycosaminoglycan building blocks supporting articular cartilage integrity' },
                    { name: 'Topical Capsaicin (0.025%) Cream', dose: 'Apply sparingly over affected joints thrice daily', purpose: 'Substance P depletion from peripheral articular nociceptors' }
                ],
                checkups: [
                    { test: 'Rheumatoid Factor (RF Quantitative) & Anti-CCP Antibodies', urgency: 'Within 72 hours', note: 'Distinguishes seropositive rheumatoid arthritis from degenerative osteoarthritis' },
                    { test: 'Serum Uric Acid & High-Sensitivity CRP', urgency: 'Routine', note: 'Excludes hyperuricemic gouty arthritis and active systemic inflammatory flare' },
                    { test: 'High-Resolution Ultrasound / MRI of Affected Joints', urgency: 'Semi-urgent', note: 'Detects synovial pannus proliferation, joint effusion, and cortical erosions' }
                ],
                hospitals: {
                    dept: 'Department of Clinical Immunology & Rheumatology',
                    names: 'Apollo Institute of Rheumatology • Medanta Bone & Joint Clinic • Fortis Rheumatology • AIIMS',
                    type: 'Specialized Arthritis & Autoimmune Joint Disease Facility',
                    query: 'rheumatologist+joint+arthritis+hospital+near+me'
                }
            },
            'rash': {
                medicines: [
                    { name: 'Fexofenadine Hydrochloride (180mg)', dose: '1 tablet once daily in evening', purpose: 'Second-generation non-sedating H1 antihistamine blocking peripheral histamine receptors' },
                    { name: 'Calamine + Pramoxine Topical Lotion', dose: 'Apply liberally over pruritic lesions 3–4 times daily', purpose: 'Soothing antipruritic with mild surface local anesthetic property' },
                    { name: 'Hydrocortisone (1%) Topical Cream', dose: 'Thin layer applied twice daily for 5 days max', purpose: 'Mild topical corticosteroid suppressing epidermal allergic inflammation' }
                ],
                checkups: [
                    { test: 'Skin Prick Allergy Panel / Total Serum IgE', urgency: 'Routine', note: 'Identifies environmental aeroallergens and food allergen triggers' },
                    { test: 'Dermatopathology Skin Punch Biopsy (3mm-4mm)', urgency: 'If atypical or non-responsive', note: 'Histopathologic evaluation of dermal lymphocytic infiltrate and vasculitis' },
                    { test: 'Patch Test for Contact Allergens (T.R.U.E. Test)', urgency: 'Elective', note: 'Pinpoints type IV delayed contact hypersensitivity agents' }
                ],
                hospitals: {
                    dept: 'Department of Dermatology & Cutaneous Medicine',
                    names: 'Kaya Skin Clinic • Apollo Dermatology • Fortis Skin Care • AIIMS Dermatology',
                    type: 'Dermatological Specialty Center with Dermatosurgery & Phototherapy Unit',
                    query: 'dermatologist+skin+hospital+near+me'
                }
            },
            'shingles': {
                medicines: [
                    { name: 'Valacyclovir (1000mg) or Acyclovir (800mg)', dose: '1000mg thrice daily for 7 days (Initiate within 72 hrs of rash)', purpose: 'Viral DNA polymerase inhibitor halting Varicella-Zoster viral replication' },
                    { name: 'Gabapentin (300mg) Capsules', dose: '1 capsule at bedtime, titrated under medical supervision', purpose: 'Suppresses post-herpetic neuralgia and sharp dermatomal nerve pain' },
                    { name: 'Topical Zinc Oxide & Calamine Lotion', dose: 'Apply to intact rash sites to promote crusting', purpose: 'Drying and soothing agent for cutaneous vesicular clusters' }
                ],
                checkups: [
                    { test: 'Varicella-Zoster Virus (VZV) PCR of Vesicular Fluid', urgency: 'Within 24 hours', note: 'Definitive molecular identification confirming acute herpes zoster infection' },
                    { test: 'Tzanck Smear from Base of Unroofed Vesicle', urgency: 'Immediate in clinic', note: 'Visualizes multinucleated viral giant cells under light microscopy' },
                    { test: 'Urgent Slit-Lamp Ophthalmic Evaluation', urgency: 'Emergency if rash near eye/nose tip (Hutchinson Sign)', note: 'Excludes Herpes Zoster Ophthalmicus and corneal dendritic keratitis' }
                ],
                hospitals: {
                    dept: 'Department of Dermatology & Infectious Neuropathy',
                    names: 'Apollo Institute of Dermatology • Fortis Infectious Wing • AIIMS • Manipal Hospital',
                    type: 'Dermatology & Pain Management Center with Ophthalmology on-call',
                    query: 'dermatologist+shingles+hospital+near+me'
                }
            }
        };

        function syncPatientData() {
            const name = document.getElementById('inp-pat-name').value || 'Jane Doe';
            const age = document.getElementById('inp-pat-age').value || '32';
            const gender = document.getElementById('inp-pat-gender').value || 'Female';
            const phone = document.getElementById('inp-pat-phone').value || '+91 98765 43210';
            const address = document.getElementById('inp-pat-address').value || 'Hyderabad';

            document.getElementById('rep-name').textContent = name;
            document.getElementById('rep-age-gender').textContent = `${age} Yrs / ${gender}`;
            document.getElementById('rep-phone').textContent = phone;
            document.getElementById('rep-address').textContent = address;
        }

        function updateReportDetails() {
            syncPatientData();

            const symptomId = appState.symptomId || 'fever';
            const data = symptomClinicalKnowledge[symptomId] || symptomClinicalKnowledge['fever'];

            const complaint = document.getElementById('report-complaint-copy');
            if (complaint) {
                complaint.innerHTML = `
                    Patient reports primary symptom onset of <strong>${appState.symptom}</strong> (${appState.symptomTelugu || ''}) in the <strong>${appState.symptomCategory}</strong> system, persisting for <strong>${appState.days} Day${appState.days > 1 ? 's' : ''}</strong> with a subjective severity score of <strong>${appState.severity}</strong>.
                `;
            }

            const badge = document.getElementById('rep-triage-badge');
            if (badge) {
                if (appState.severity.includes('Critical') || (appState.days >= 7 && appState.severity.includes('Severe'))) {
                    badge.textContent = 'HIGH PRIORITY';
                    badge.style.color = '#f43f5e';
                } else if (appState.severity.includes('Severe') || appState.days >= 6) {
                    badge.textContent = 'MODERATE ATTENTION';
                    badge.style.color = '#fbbf24';
                } else {
                    badge.textContent = 'LOW RISK';
                    badge.style.color = '#34d399';
                }
            }

            const medContainer = document.getElementById('report-medicines-list');
            if (medContainer && data.medicines) {
                medContainer.innerHTML = data.medicines.map(m => `
                    <div class="report-med-item">
                        <div class="med-title-row">
                            <span class="med-name">💊 ${m.name}</span>
                            <span class="med-dose">${m.dose}</span>
                        </div>
                        <div class="med-purpose">Indication: ${m.purpose}</div>
                    </div>
                `).join('');
            }

            const checkupContainer = document.getElementById('report-checkups-list');
            if (checkupContainer && data.checkups) {
                checkupContainer.innerHTML = data.checkups.map(t => `
                    <div class="report-test-item">
                        <div class="test-title-row">
                            <span class="test-name">🔬 ${t.test}</span>
                            <span class="test-urgency">${t.urgency}</span>
                        </div>
                        <div class="test-rationale">Diagnostic Objective: ${t.note}</div>
                    </div>
                `).join('');
            }

            const hospContainer = document.getElementById('report-hospital-recommendation');
            if (hospContainer && data.hospitals) {
                hospContainer.innerHTML = `
                    <div class="hospital-details">
                        <h4>🏥 ${data.hospitals.dept}</h4>
                        <p>${data.hospitals.type}</p>
                        <p><strong>Premier Recommended Networks:</strong> ${data.hospitals.names}</p>
                        <small>✓ 24/7 Diagnostic Pathology & Inpatient Capacity Verified</small>
                    </div>
                    <a href="https://www.google.com/maps/search/${encodeURIComponent(data.hospitals.query)}" target="_blank" rel="noopener noreferrer" class="hosp-route-btn">
                        <span>🗺️</span> <span>NAVIGATE ON GOOGLE MAPS</span>
                    </a>
                `;
            }
        }

        updateReportDetails();
    

/* --- Extracted script block --- */


      (function(){
        'use strict';
        const $ = id => document.getElementById(id);
        let reminderTimer = null;
        let baseFontSize = null;
        const profileKey = 'shw_health_hub_profile_v1';
        function safeText(el, value){ if(el) el.textContent = value; }

        window.hhAsk = function(){
          const q = ($('hh-question')?.value || '').trim().toLowerCase();
          let answer;
          if(!q){ answer = 'Please enter a health question first.'; }
          else if(/chest pain|difficulty breathing|can't breathe|cannot breathe|sudden weakness|stroke|unconscious|severe bleeding|severe allergic/.test(q)){
            answer = 'This may be an emergency. Call your local emergency number or seek emergency medical care now. In India, call 112. Do not wait for this website to assess the situation.';
          } else if(/fever|temperature/.test(q)){
            answer = 'General guidance: rest, drink fluids if you can, and monitor symptoms. Seek medical advice if the fever persists, worsens, or you are worried. Seek urgent care for severe symptoms. This tool cannot determine the cause of a fever.';
          } else if(/headache|head pain/.test(q)){
            answer = 'Headaches can have many causes. Rest and hydration may help some mild headaches. Seek urgent care for a sudden severe headache, headache after a serious injury, or headache with confusion, weakness, fever and stiff neck, or vision changes.';
          } else if(/medicine|medication|dose|tablet|drug/.test(q)){
            answer = 'Use medicines only according to the package label and instructions from your clinician or pharmacist. Do not start, stop, combine, or change doses based on this helper. Ask a pharmacist or clinician about interactions and allergies.';
          } else if(/water|hydration|drink/.test(q)){
            answer = 'Regular fluids can help maintain hydration. Needs vary by person and medical condition; follow any fluid limits given by your healthcare professional.';
          } else if(/doctor|appointment|prepare/.test(q)){
            answer = 'For a healthcare visit, note your symptoms and when they started, medicines and supplements, allergies, relevant measurements, and questions you want answered.';
          } else {
            answer = 'I can provide only basic general information in this offline demo. For advice specific to your symptoms, contact a qualified healthcare professional. If symptoms are severe or rapidly worsening, seek urgent medical care.';
          }
          safeText($('hh-answer'), answer);
        };
        window.hhSpeak = function(){
          const text = $('hh-answer')?.textContent || '';
          if(!text || !('speechSynthesis' in window)){ safeText($('hh-profile-status'),'Speech playback is not supported by this browser.'); return; }
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(text);
          try { utterance.lang = (typeof currentLanguage !== 'undefined' && currentLanguage === 'te') ? 'te-IN' : 'en-IN'; } catch(e) { utterance.lang = 'en-IN'; }
          window.speechSynthesis.speak(utterance);
        };
        window.hhSaveProfile = function(){
          const data = {name:($('hh-name')?.value||'').trim(), notes:($('hh-allergies')?.value||'').trim(), updatedAt:new Date().toISOString()};
          try { localStorage.setItem(profileKey, JSON.stringify(data)); safeText($('hh-profile-status'),'Saved on this device in this browser.'); }
          catch(e){ safeText($('hh-profile-status'),'Could not save notes in this browser.'); }
        };
        window.hhClearProfile = function(){
          try { localStorage.removeItem(profileKey); } catch(e){}
          if($('hh-name')) $('hh-name').value=''; if($('hh-allergies')) $('hh-allergies').value='';
          safeText($('hh-profile-status'),'Saved notes cleared from this browser.');
        };
        window.hhSetReminder = function(){
          window.hhCancelReminder(false);
          const label = ($('hh-reminder-text')?.value||'').trim();
          const raw = $('hh-reminder-time')?.value;
          const when = raw ? new Date(raw).getTime() : NaN;
          if(!label || !Number.isFinite(when) || when <= Date.now()){ safeText($('hh-reminder-status'),'Enter a description and a future date/time.'); return; }
          const delay = when-Date.now();
          if(delay > 2147480000){ safeText($('hh-reminder-status'),'Please choose a reminder within about 24 days.'); return; }
          reminderTimer = window.setTimeout(()=>{
            alert('Health reminder: '+label);
            if('Notification' in window && Notification.permission === 'granted') { try { new Notification('Health reminder',{body:label}); } catch(e){} }
            safeText($('hh-reminder-status'),'Reminder shown. Set another reminder if needed.'); reminderTimer=null;
          }, delay);
          safeText($('hh-reminder-status'),'Reminder set for '+new Date(when).toLocaleString()+'. Keep this page open; reminders may not run if the page is closed.');
          if('Notification' in window && Notification.permission === 'default') { try { Notification.requestPermission(); } catch(e){} }
        };
        window.hhCancelReminder = function(updateText=true){
          if(reminderTimer !== null){ clearTimeout(reminderTimer); reminderTimer=null; }
          if(updateText) safeText($('hh-reminder-status'),'Reminder cancelled.');
        };
        window.hhFindCare = function(kind){
          const place = ($('hh-place')?.value||'').trim();
          const query = kind + (place ? ' near '+place : ' near me');
          const url = 'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(query);
          safeText($('hh-care-status'),'Opening a map search. Confirm the facility details and availability directly.');
          window.open(url,'_blank','noopener,noreferrer');
        };
        window.hhEmergencyInfo = function(){
          safeText($('hh-care-status'),'If you are in India and need emergency assistance, call 112. This website does not place emergency calls automatically.');
          window.open('https://112.gov.in/','_blank','noopener,noreferrer');
        };
        window.hhPrintSummary = function(){
          const name = ($('hh-name')?.value||'').trim();
          const notes = ($('hh-allergies')?.value||'').trim();
          const w = window.open('','_blank');
          if(!w){ alert('Allow pop-ups to print or save the summary as PDF.'); return; }
          const esc = str => str.replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
          w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Personal Health Summary</title><style>body{font:16px Arial,sans-serif;max-width:760px;margin:40px auto;padding:0 20px;color:#172b3a}h1{color:#075985}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit;border:1px solid #ccc;padding:12px}small{color:#555}</style></head><body><h1>Personal Health Summary</h1><p><b>Date:</b> '+esc(new Date().toLocaleString())+'</p><p><b>Display name:</b> '+esc(name||'Not provided')+'</p><h2>Allergies / important notes</h2><pre>'+esc(notes||'No notes entered')+'</pre><small>This is a user-entered personal summary, not a verified medical record or diagnosis. Review before sharing.</small><script>window.onload=function(){window.print()}<\/script></body></html>');
          w.document.close();
        };
        window.hhTextSize = function(direction){
          if(baseFontSize===null) baseFontSize = parseFloat(getComputedStyle(document.body).fontSize)||16;
          const size = direction===0 ? baseFontSize : Math.max(13,Math.min(22,baseFontSize+(direction>0?2:-2)));
          document.body.style.fontSize = size+'px';
          safeText($('hh-access-status'),'Text size: '+Math.round(size)+'px.');
        };
        const symptomKey = 'shw_health_hub_symptoms_v1';
        const measurementKey = 'shw_health_hub_measurements_v1';
        const appointmentKey = 'shw_health_hub_appointments_v1';
        const dataKeys = [profileKey, symptomKey, measurementKey, appointmentKey];
        function loadList(key){ try { const v=JSON.parse(localStorage.getItem(key)||'[]'); return Array.isArray(v)?v:[]; } catch(e){ return []; } }
        function saveList(key, list, statusId){ try { localStorage.setItem(key,JSON.stringify(list)); if(statusId) safeText($(statusId),'Saved on this device in this browser.'); return true; } catch(e){ if(statusId) safeText($(statusId),'Could not save. Browser storage may be full or unavailable.'); return false; } }
        function escHtml(value){ return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
        function renderList(id, items, emptyText, formatter){ const el=$(id); if(!el)return; if(!items.length){el.textContent=emptyText;return;} el.innerHTML=items.slice().reverse().map(item=>'<div class="hh-record">'+formatter(item)+'</div>').join(''); }
        function renderSymptoms(){ renderList('hh-symptom-list',loadList(symptomKey),'No symptom entries saved yet.',x=>'<strong>'+escHtml(x.symptom)+'</strong> · '+escHtml(x.date)+'<small>Impact: '+escHtml(x.severity)+'/10'+(x.notes?' · '+escHtml(x.notes):'')+'</small>'); }
        function renderMeasurements(){ renderList('hh-measure-list',loadList(measurementKey),'No measurements saved yet.',x=>'<strong>'+escHtml(x.type)+': '+escHtml(x.value)+'</strong><small>'+escHtml(x.date)+'</small>'); }
        function renderAppointments(){ renderList('hh-appt-list',loadList(appointmentKey),'No appointments saved yet.',x=>'<strong>'+escHtml(x.title)+'</strong><small>'+escHtml(x.date)+(x.location?' · '+escHtml(x.location):'')+'</small>'+(x.questions?'<small>Questions: '+escHtml(x.questions)+'</small>':'')); }
        window.hhAddSymptom=function(){ const symptom=($('hh-symptom')?.value||'').trim(); if(!symptom){safeText($('hh-data-status'),'Enter a symptom before saving.');return;} const date=$('hh-symptom-start')?.value; const list=loadList(symptomKey); list.push({symptom,date:date?new Date(date).toLocaleString():'Date not specified',severity:$('hh-symptom-severity')?.value||'3',notes:($('hh-symptom-notes')?.value||'').trim(),createdAt:new Date().toISOString()}); if(saveList(symptomKey,list,'hh-data-status')){ $('hh-symptom').value='';$('hh-symptom-notes').value='';renderSymptoms();} };
        window.hhClearSymptoms=function(){if(!confirm('Delete all saved symptom journal entries from this browser?'))return;localStorage.removeItem(symptomKey);renderSymptoms();safeText($('hh-data-status'),'Symptom journal cleared from this browser.');};
        window.hhAddMeasurement=function(){const value=($('hh-measure-value')?.value||'').trim();if(!value){safeText($('hh-data-status'),'Enter a measurement value before saving.');return;}const date=$('hh-measure-date')?.value;const list=loadList(measurementKey);list.push({type:$('hh-measure-type')?.value||'Other',value,date:date?new Date(date).toLocaleString():new Date().toLocaleString(),createdAt:new Date().toISOString()});if(saveList(measurementKey,list,'hh-data-status')){$('hh-measure-value').value='';renderMeasurements();}};
        window.hhClearMeasurements=function(){if(!confirm('Delete all saved measurements from this browser?'))return;localStorage.removeItem(measurementKey);renderMeasurements();safeText($('hh-data-status'),'Measurements cleared from this browser.');};
        window.hhAddAppointment=function(){const title=($('hh-appt-title')?.value||'').trim();const raw=$('hh-appt-date')?.value;if(!title||!raw){safeText($('hh-data-status'),'Enter an appointment name and date/time.');return;}const list=loadList(appointmentKey);list.push({title,date:new Date(raw).toLocaleString(),location:($('hh-appt-location')?.value||'').trim(),questions:($('hh-appt-questions')?.value||'').trim(),createdAt:new Date().toISOString()});if(saveList(appointmentKey,list,'hh-data-status')){$('hh-appt-title').value='';$('hh-appt-location').value='';$('hh-appt-questions').value='';renderAppointments();}};
        window.hhClearAppointments=function(){if(!confirm('Delete all saved appointments from this browser?'))return;localStorage.removeItem(appointmentKey);renderAppointments();safeText($('hh-data-status'),'Appointments cleared from this browser.');};
        window.hhExportData=function(){const payload={exportedAt:new Date().toISOString(),notice:'Personal user-entered data; not a verified medical record.',profile:(()=>{try{return JSON.parse(localStorage.getItem(profileKey)||'null')}catch(e){return null}})(),symptoms:loadList(symptomKey),measurements:loadList(measurementKey),appointments:loadList(appointmentKey)};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='health-hub-backup-'+new Date().toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);safeText($('hh-data-status'),'Export prepared. Keep the downloaded file private because it may contain sensitive health information.');};
        window.hhDeleteAllData=function(){if(!confirm('Delete all Health Hub profile notes, symptoms, measurements, and appointments stored by this website in this browser? This cannot be undone.'))return;dataKeys.forEach(k=>{try{localStorage.removeItem(k)}catch(e){}});if($('hh-name'))$('hh-name').value='';if($('hh-allergies'))$('hh-allergies').value='';renderSymptoms();renderMeasurements();renderAppointments();safeText($('hh-data-status'),'Health Hub data deletion requested for this browser. Other website data and exported files are not affected.');safeText($('hh-profile-status'),'Saved notes cleared from this browser.');};
        function updateOnline(){ safeText($('hh-online-status'), navigator.onLine ? 'Browser reports an internet connection.' : 'You appear to be offline. Online searches and external services may not work.'); }
        window.addEventListener('online',updateOnline,{passive:true}); window.addEventListener('offline',updateOnline,{passive:true});
        document.addEventListener('DOMContentLoaded',function(){
          try { const data=JSON.parse(localStorage.getItem(profileKey)||'null'); if(data){ if($('hh-name')) $('hh-name').value=data.name||''; if($('hh-allergies')) $('hh-allergies').value=data.notes||''; } } catch(e){}
          renderSymptoms(); renderMeasurements(); renderAppointments();
          updateOnline();
        },{once:true});
      })();
    

/* --- Extracted script block --- */


      // Remove the mouse-tilt effect that was rotating the whole page.
      window.addEventListener('DOMContentLoaded', function () {
        const shell = document.querySelector('.main-shell');
        if (shell) {
          shell.style.setProperty('transform', 'none', 'important');
          shell.style.setProperty('transform-style', 'flat', 'important');
        }
        document.querySelectorAll('.cursor-aura, #cursor-aura, .cursor-glow').forEach(el => el.remove());
      });
    

/* --- Extracted script block --- */


      (function () {
        const screen = document.getElementById('hh-login-screen');
        const form = document.getElementById('hh-login-form');
        const email = document.getElementById('hh-login-email');
        const password = document.getElementById('hh-login-password');
        const message = document.getElementById('hh-login-message');
        const card = form;
        const showBtn = document.getElementById('hh-show-password');
        const remember = document.getElementById('hh-remember-me');
        const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

        function enterDemo() {
          document.body.classList.add('hh-authenticated');
          screen.hidden = true;
          message.textContent = '';
          window.scrollTo(0, 0);
        }
        form.addEventListener('submit', function (event) {
          event.preventDefault();
          if (!email.checkValidity()) { email.reportValidity(); return; }
          if (!password.checkValidity()) { password.reportValidity(); return; }
          // Demo-only gate: intentionally does not store or transmit credentials.
          if (remember.checked) {
            try { sessionStorage.setItem('hh-demo-session', '1'); } catch (e) {}
          }
          enterDemo();
        });
        showBtn.addEventListener('click', function () {
          const reveal = password.type === 'password';
          password.type = reveal ? 'text' : 'password';
          showBtn.textContent = reveal ? 'Hide' : 'Show';
          showBtn.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
        });
        document.getElementById('hh-forgot-password').addEventListener('click', function () {
          message.style.color = '#fcd34d';
          message.textContent = 'This demo has no account service. Password reset becomes available when a secure backend is connected.';
        });
        if (card && !reducedMotion) {
          card.addEventListener('pointermove', function (event) {
            if (event.pointerType === 'touch' || window.innerWidth < 760) return;
            const rect = card.getBoundingClientRect();
            const x = (event.clientX - rect.left) / rect.width;
            const y = (event.clientY - rect.top) / rect.height;
            card.style.setProperty('--hh-mx', (x * 100) + '%');
            card.style.setProperty('--hh-my', (y * 100) + '%');
            card.style.transform = 'rotateX(' + ((.5 - y) * 3.5) + 'deg) rotateY(' + ((x - .5) * 4) + 'deg) translateZ(3px)';
          });
          card.addEventListener('pointerleave', function () { card.style.transform = ''; });
        }
        try {
          if (sessionStorage.getItem('hh-demo-session') === '1') enterDemo();
          else setTimeout(function () { if (!screen.hidden) email.focus(); }, 350);
        } catch (e) { setTimeout(function () { if (!screen.hidden) email.focus(); }, 350); }
      })();
    